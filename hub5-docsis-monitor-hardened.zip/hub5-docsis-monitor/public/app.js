import {timeline} from './timeline.js';
import {powerChart} from './power.js';

const $ = id => document.getElementById(id);
const labels = {power:'Power (dBmV)',mer:'MER/SNR (dB)',lock:'Channel lock',corrected:'Corrected codewords Δ',uncorrectable:'Uncorrectable codewords Δ',t1:'T1 Δ',t2:'T2 Δ',t3:'T3 Δ',t4:'T4 Δ'};
const counter = metric => !['power','mer','lock'].includes(metric);
const time = ms => new Date(ms).toLocaleString('en-GB',{timeZone:'Europe/London'});
const escape = s => String(s ?? '—').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const heading = s => ({downstream:'Downstream',upstream:'Upstream',eventlog:'Network log'})[s] ?? s;
const channelLabel = key => {
  const [type,id,frequency] = JSON.parse(key);
  return type+' · '+id+(frequency != null && frequency !== id ? ' · '+frequency : '');
};
let status, range, zoom, eventData, catalogue;
let active='downstream', powerMode='time', chartState={}, detail;
let live={}, eventQuery, eventContext, powerZoom, historyPin;
const isPaused=()=>live.paused ?? status?.paused ?? false;
const fixedPower=()=>Boolean(eventContext || powerZoom || isPaused());
const frequencyLabel=hz=>hz==null?'—':new Intl.NumberFormat('en-GB',{maximumFractionDigits:4}).format(hz/1e6)+' MHz';
let lastStatusDraw=0;
const liveStamp=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',hour:'2-digit',minute:'2-digit',
  second:'2-digit',fractionalSecondDigits:3});
const collectorNow=()=>live.clock ? Math.round(live.clock.serverTime+performance.now()-live.clock.mono) : Date.now();
const needsLiveHistory=()=>active==='history' && !historyPin && !zoom && Number($('range').value)>0 && Number($('range').value)<=300;
const liveDirection=()=>signals() ? active : needsLiveHistory() ? $('direction').value : null;
const signals = () => active==='downstream' || active==='upstream';
const historyHref=(direction,key,span,at,mode)=>'#history?'+new URLSearchParams({direction,key,
  ...(span?{span}:{}),...(at?{at}:{}),...(mode?{kind:mode}:{}),
  ...(eventQuery?.event?{event:eventQuery.event}:{})});
const eventHref=(direction,query)=>'#'+direction+'?'+new URLSearchParams(query);
const multiChart=powerChart((key,at)=>{
  const eventTime=eventContext?.event.time;
  return historyHref(active,key,$('power-range').value,eventTime ?? at,eventTime?'event':null);
},view=>{
  if (view) {
    const width=Math.min(366*86400000,view.to-view.from);
    const from=Math.max(0,view.from);
    powerZoom={from,to:from+width};
  } else powerZoom=null;
  refresh(undefined,true);
});
let dashboardJob, chartJob, dashboardBusy = false, chartBusy = false;
let lastExtra = {direction:null,keys:[]};
const chart = timeline(view => { zoom = view; connectLive(); refreshTimeline(undefined,true); });
const duration = ms => ms < 1000 ? ms+' ms' : ms/1000+' s';
function showError(message) {
  $('error').textContent = message ?? '';
  $('error').hidden = !message;
}
async function request(url, options) {
  const response = await fetch(url,options);
  const data = await response.json();
  if (!response.ok) throw Error(data.error ?? response.statusText);
  return data;
}
function table(headers, rows, channelHref) {
  if (!rows.length) return '<small>No records in this view.</small>';
  return '<div class="table-wrap"><table><thead><tr>'+headers.map(x=>'<th scope="col">'+escape(x)+'</th>').join('')+
    '</tr></thead><tbody>'+rows.map((row,i)=>'<tr>'+row.map((x,j)=>'<td>'+(j===0 && channelHref ? '<a href="'+escape(channelHref(i))+'">'+escape(x)+'</a>' : escape(x))+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
}
function options(select, values) {
  const previous = select.value;
  select.replaceChildren(...values.map(([key,name])=>new Option(name,key)));
  if (values.some(([key])=>key===previous)) select.value = previous;
}
function renderStatus() {
  const paused=isPaused();
  $('hub').textContent=status.hub+' · UK local time · '+(paused?'Polling paused':duration(status.cadenceMs.downstream)+' RF capture target');
  const polling=$('polling-switch');
  if (polling.getAttribute('aria-busy')!=='true') {polling.checked=!paused;polling.disabled=false;}
  $('polling-description').textContent=paused?'Collection is off. Saved readings are still available.':
    'Collecting readings from the Hub. You can pause all modem requests here.';
  $('sources').innerHTML = ['downstream','upstream','eventlog'].map(source=>{
    const entry = status.status.find(s=>s.source===source);
    const stale = entry?.attempted && Date.now()-entry.attempted > status.cadenceMs[source]*2+15000;
    const state = paused ? 'Polling paused' : entry?.error ? 'Endpoint error' : stale ? 'Poll overdue' : entry?.good ? 'Collecting' : 'Awaiting first poll';
    return '<article class="card"><h3>'+heading(source)+'</h3><p class="'+(paused ? 'muted' : entry?.error || stale ? 'warning' : 'status')+'">'+state+
      '</p><small>'+escape(entry?.error ?? (entry?.good ? 'Last success '+time(entry.good) : 'No successful sample yet'))+'</small><br><small>Target '+duration(status.cadenceMs[source])+'</small></article>';
  }).join('');
  // Keep a focused channel link in place when readings are changing.
  if (!$('channel-tables').contains(document.activeElement)) $('channel-tables').innerHTML = ['downstream','upstream'].map(direction=>{
    const metrics = direction==='downstream' ? ['power','mer','corrected','uncorrectable'] : ['power','t1','t2','t3','t4'];
    const rows = status.current[direction];
    const usable = metrics.some(k=>rows.some(row=>row[k]!=null));
    const missing = rows.length && !usable ? '<p>RF field mapping unavailable. Hub fields include '+escape(Object.keys(Object.fromEntries(rows.flatMap(row=>row.fields.map(k=>[k,true])))).join(', '))+'.</p>' : '';
    return '<article class="panel"'+(direction!==active?' hidden':'')+'><p class="eyebrow">'+heading(direction)+'</p><h2>Latest channel measurements</h2>'+missing+
      table(['Channel','Type','Centre frequency¹','Modulation','Status',...metrics.map(k=>labels[k].replace(' Δ',''))],
        rows.map(r=>[r.id ?? r.frequency,r.type,frequencyLabel(r.frequencyHz),r.modulation,r.status,...metrics.map(k=>r[k])]),
        i=>historyHref(direction,rows[i].key,$('power-range').value))+
      '<small>¹ Frequency as reported by the Hub. Counters are cumulative.</small></article>';
  }).join('');
  if (!$('settings-form').contains(document.activeElement)) {
    if (!$('settings-form').dataset.dirty) {
      $('interval').value = status.settings.interval;
      syncIntervalSlider();
      $('retention').value = status.settings.retention;
    }
  }
}
function queryRange(from,to) {
  return {from,to,query:new URLSearchParams({from,to}).toString()};
}
function rollingRange(seconds,direction) {
  const last=isPaused() && direction ? status?.status.find(row=>row.source===direction)?.good : null;
  const to=last || collectorNow();
  return queryRange(to-Number(seconds)*1000,to);
}
function selectedRange() {
  if (historyPin) {
    const radius=historyPin.kind==='event'?120000:30000;
    return queryRange(Math.max(0,historyPin.at-radius),historyPin.at+radius);
  }
  const seconds = $('range').value;
  if (seconds!=='custom') return rollingRange(seconds,$('direction').value);
  const now = collectorNow();
  const from = seconds === 'custom' ? new Date($('from').value).getTime() : now-Number(seconds)*1000;
  const to = seconds === 'custom' ? new Date($('to').value).getTime() : now;
  if (!Number.isFinite(from) || !Number.isFinite(to) || from<0 || from>=to || to-from>366*86400000) throw Error('Choose a valid start and end time up to 366 days apart.');
  return {from,to,query:new URLSearchParams({from,to}).toString()};
}
function renderEvents() {
  if (!eventData) return;
  $('event-title').textContent = 'Event log · '+eventData.total+' entries'+(eventData.total>eventData.events.length?' · latest '+eventData.events.length:'');
  const selected = $('severity').value;
  const eventRows=eventData.events.filter(r=>!selected || r.priority===selected);
  $('event-table').innerHTML=table(['Time (UK) · Open in charts','Severity','Message'],
    eventRows.map(r=>[time(r.time),r.priority,r.message]),i=>eventHref(eventRows[i].reference?.direction ?? 'upstream',{event:eventRows[i].id}));
  $('summary').innerHTML = table(['Date','Entries','Critical','T1','T2','T3','T4'],Object.entries(eventData.summaries).map(([date,s])=>[date,s.events,s.critical,s.T1,s.T2,s.T3,s.T4]));
  $('incidents').innerHTML = eventData.incidents.map(g=>'<details><summary>'+escape(time(g.first))+' · '+
    escape(Object.entries(g.tags).map(([k,v])=>k+' × '+v).join(', '))+'</summary><p>Last entry '+escape(time(g.last))+'</p><p><a href="'+escape(eventHref('upstream',{at:g.first}))+'">Investigate on charts →</a></p>'+
    (g.ranging.length ? table(['Poll time (UK)','Channel','Type','T3 Δ','T4 Δ'],g.ranging.flatMap(p=>p.channels.map(r=>[time(p.time),r.id,r.type,r.t3,r.t4]))) : '')+
    Object.entries(g.rf).map(([direction,rf])=>{
      if (!rf) return '<p>'+heading(direction)+' · No nearby RF samples.</p>';
      const total = Object.entries(rf.totals).map(([k,v])=>labels[k]+' '+v).join(' · ');
      return '<p>'+heading(direction)+' · '+escape(time(rf.from)+' to '+time(rf.to))+
        (rf.from===rf.to?' · single sample':' · '+rf.added+' added / '+rf.removed+' removed')+'</p>'+
        (total?'<p>'+escape(total)+'</p>':'')+(rf.resets.length?'<p>Counter decreases: '+escape(rf.resets.join(', '))+'</p>':'')+
        (rf.changes.length?table(['Channel','Type','Power Δ (dB)','MER Δ (dB)','Lock change'],rf.changes.map(r=>[r.id,r.type,r.power,r.mer,r.lock==null?'—':r.lock?'Locked':'Unlocked'])):'');
    }).join('')+'</details>').join('') || '<small>No ranging or DRW incidents in this range.</small>';
}
function selectKeys(direction,extra=[],wanted=$('channel').value) {
  const keys = [...new Set([...(status?.current[direction] ?? []).map(r=>r.key),
    ...(catalogue?.[direction] ?? []),...extra])];
  options($('channel'),keys.map(k=>[k,channelLabel(k)]));
  if (keys.includes(wanted)) $('channel').value = wanted;
  $('channel').disabled = !keys.length;
}
async function refreshTimeline(wanted, clear=false) {
  if (!range) return;
  chartJob?.abort();
  const job = chartJob = new AbortController();
  chartBusy = true;
  const view = zoom ?? range;
  const query = new URLSearchParams({from:view.from,to:view.to});
  const direction = $('direction').value, metric = $('metric').value;
  const label = $('plot-label');
  const keyBefore = wanted ?? $('channel').value;
  if (clear) {
    detail = null;
    chart.render(view,null,Boolean(zoom));
    label.textContent = 'Loading timeline…';
  }
  try {
    const extra = zoom ? (await request('/api/channels?'+query,{signal:job.signal}))[direction] : [];
    if (job.signal.aborted) return;
    const keep = lastExtra.direction===direction && lastExtra.keys.includes(keyBefore) ? [keyBefore] : [];
    lastExtra = {direction,keys:[...extra,...keep]};
    selectKeys(direction,lastExtra.keys,keyBefore);
    const key = $('channel').value;
    if (!key) {
      chart.render(view,null,Boolean(zoom));
      label.textContent = 'No channels in this range.';
      return;
    }
    for (const [param,value] of Object.entries({direction,key,metric,seriesOnly:'1'})) query.set(param,value);
    const {history:rows,bucketMs} = await request('/api/history?'+query,{signal:job.signal});
    if (job.signal.aborted) return;
    detail={key,direction,metric,rows,bucketMs,view,
      identity:direction+' '+key+' '+metric,isCounter:counter(metric),interval:status.settings.interval,
      marker:historyPin?.at,markerLabel:historyPin?.kind==='event'?'Event':'Selected time'};
    if (!isPaused() && needsLiveHistory() && bucketMs===1) {
      for (const frame of live.frames ?? []) appendDetail(frame);
      advanceDetail(Math.max(view.to,collectorNow()));
    } else renderDetail();
  } catch (error) {
    if (job.signal.aborted) return;
    chart.render(view,null,Boolean(zoom));
    label.textContent = 'Timeline unavailable: '+error.message;
  } finally {
    if (job===chartJob) chartBusy = false;
  }
}
function renderDetail() {
  const {key,metric,rows,bucketMs,view,isCounter}=detail;
  const measured=rows.filter(p=>p.count).length;
  const resets=rows.reduce((n,p)=>n+p.resets,0);
  $('plot-label').textContent=channelLabel(key)+' · '+labels[metric]+' · '+(measured ?
    measured+(bucketMs===1?' captures':' intervals')+(isCounter?' · observed deltas':bucketMs===1?'':' · mean and min/max') :
    'No measured values in this view')+(resets?' · '+resets+' decreases':'');
  chart.render(view,detail,Boolean(zoom));
}
function appendDetail(frame) {
  if (!detail || detail.direction!==frame.direction || detail.bucketMs!==1 || frame.time<detail.view.from ||
      (detail.rows.at(-1)?.time ?? -1)>=frame.time) return;
  const row=frame.rows.find(r=>r.key===detail.key);
  if (!row) return;
  const value=detail.isCounter ? row.delta?.[detail.metric] : row[detail.metric];
  const valid=Number.isFinite(value);
  detail.interval=frame.cadenceMs/1000;
  detail.rows.push({time:frame.time,last:frame.time,min:valid?value:null,max:valid?value:null,
    sum:valid?value:null,count:Number(valid),resets:Number(row.reset?.includes(detail.metric) ?? false)});
}
function advanceDetail(to) {
  if (isPaused() || !detail || !needsLiveHistory() || detail.bucketMs!==1) return;
  const from=to-Number($('range').value)*1000;
  detail.view={from,to};
  while (detail.rows.length && detail.rows[0].time<from) detail.rows.shift();
  renderDetail();
}
function appendPower(frame) {
  if (!chartState.range || frame.time<chartState.range.from) return;
  const byKey=chartState.byKey ??= new Map(chartState.snapshot.map(ch=>[ch.key,ch]));
  const bucketMs=chartState.bucketMs;
  for (const row of frame.rows) {
    let series=byKey.get(row.key);
    if(!series) {
      if(!Number.isFinite(row.power))continue;
      series={key:row.key,points:[]};
      byKey.set(row.key,series);
      chartState.snapshot.push(series);
    }
    const points=series.points;
    const last=points.at(-1);
    if (last && frame.time<=last.time) continue;
    const next={time:frame.time,power:row.power};
    if (last && bucketMs>1 && Math.floor(last.time/bucketMs)===Math.floor(next.time/bucketMs)) points[points.length-1]=next;
    else points.push(next);
  }
}
function advancePower(to) {
  if (!chartState.range || fixedPower()) return;
  to=Math.max(to,chartState.range.to);
  const from=to-Number($('power-range').value)*1000;
  chartState.range={from,to};
  for (const {points} of chartState.snapshot) while(points.length && points[0].time<from) points.shift();
  multiChart.setData(chartState={...chartState,...powerSnapshot()});
}
function applyLiveStatus(frame) {
  if (!status || !frame) return;
  const direction=frame.direction;
  let entry=status.status.find(s=>s.source===direction);
  if (entry?.attempted>frame.time) return;
  if (!entry) status.status.push(entry={source:direction});
  entry.attempted=frame.time;
  entry.error=frame.error ?? null;
  if (!frame.error) {
    entry.good=frame.time;
    status.current[direction]=frame.rows;
    status.cadenceMs[direction]=frame.cadenceMs;
  }
}
function liveBadge() {
  const box=$('live-monitor'), badge=$('live-indicator'), clock=$('live-clock');
  box.hidden=!live.direction;
  if (!live.direction) return;
  const late=live.error || (live.sample && collectorNow()-live.sample.serverTime>Math.max(live.sample.cadenceMs*3,2000));
  const [state,label]=isPaused()?['paused','Polling paused']:!live.open ? ['offline',live.reconnecting?'Reconnecting':'Connecting'] :
    late ? ['late','Awaiting readings'] : live.sample ? ['live','Live'] : ['waiting','Waiting for first reading'];
  if (badge.textContent!==label) {
    badge.textContent=label;
    badge.dataset.state=state;
  }
  const text=live.sample?'Last sample '+liveStamp.format(live.sample.time)+' UK':'';
  if (clock.textContent!==text) {
    clock.textContent=text;
    if (live.sample) clock.dateTime=new Date(live.sample.time).toISOString();
    else clock.removeAttribute('datetime');
  }
}
function connectLive() {
  const direction=liveDirection();
  if (direction===live.direction) return;
  live.stream?.close();
  live={direction,frames:[]};
  liveBadge();
  if (!direction || typeof EventSource==='undefined') return;
  const local=live;
  const stream=local.stream=new EventSource('/api/live?'+new URLSearchParams({direction}));
  stream.addEventListener('ready',event=>{
    if(live!==local)return;
    const {serverTime,paused}=JSON.parse(event.data);
    local.paused=paused;
    local.clock={serverTime,mono:performance.now()};
    local.open=true;
    if (local.reconnecting && !dashboardBusy) refresh();
    local.reconnecting=false;
    liveBadge();
  });
  stream.onerror=()=>{
    if(live!==local)return;
    local.open=false;
    local.reconnecting=true;
    liveBadge();
  };
  stream.addEventListener('capture-state',event=>{
    if(live!==local)return;
    const {paused}=JSON.parse(event.data);
    local.paused=paused;
    if(status) {status.paused=paused;renderStatus();}
    liveBadge();
    refresh(undefined,true);
  });
  stream.addEventListener('capture-error',event=>{
    if(live!==local)return;
    const frame=JSON.parse(event.data);
    applyLiveStatus(local.last=frame);
    local.error=frame.error;
    liveBadge();
    if (signals()) multiChart.setData(chartState={...chartState,...powerSnapshot()});
  });
  stream.addEventListener('sample',event=>{
    if(live!==local)return;
    const frame=JSON.parse(event.data);
    local.error=null;
    if (local.sample?.time>=frame.time) {liveBadge();return;}
    local.sample=local.last=frame;
    local.frames.push(frame);
    if (local.frames.length>120) local.frames.shift();
    applyLiveStatus(frame);
    liveBadge();
    if (status && performance.now()-lastStatusDraw>=900) {
      lastStatusDraw=performance.now();
      renderStatus();
    }
    if (signals()) {
      if (powerMode==='time') {
        if (!fixedPower()) {
          appendPower(frame);
          advancePower(Math.max(frame.time,collectorNow()));
        }
      } else if (!eventContext) multiChart.setData(chartState={...chartState,...powerSnapshot()});
    } else if(needsLiveHistory()) {
      appendDetail(frame);
      advanceDetail(Math.max(frame.time,collectorNow()));
    }
  });
}
function powerSnapshot() {
  const source=status?.status.find(s=>s.source===active);
  return {current:status?.current[active] ?? [],captured:source?.good,
    marker:eventContext?.event.time,compare:eventContext?.directions[active],frozen:fixedPower(),zoomed:Boolean(powerZoom),
    sourceError:source?.error || (source?.attempted && Date.now()-source.attempted>(status?.cadenceMs[active] ?? 60000)*2+15000),
    cadenceMs:status?.cadenceMs[active] ?? 60000};
}
function renderInvestigation() {
  const box=$('event-context');
  box.hidden=!eventQuery;
  if (!eventQuery) return;
  if(!eventContext) {box.textContent='Loading event evidence…';return;}
  const {event,reference,directions}=eventContext;
  const side=directions[active], other=active==='upstream'?'downstream':'upstream';
  const named=reference.channel!=null ? ' Log reference: '+(reference.direction ?? '')+' channel '+reference.channel+
    (reference.explicitId?' (ID).':' (number; no verified ID mapping).') : '';
  const evidence=side.rows.filter(row=>row.reason.length);
  const snapshots='Before: '+(side.before==null?'no sample':time(side.before))+' · After: '+(side.after==null?'no sample':time(side.after));
  box.innerHTML='<p class="eyebrow">Event investigation · '+escape(time(event.time))+' UK</p><h2>'+escape(event.priority)+'</h2>'+
    '<p>'+escape(event.message+named)+'</p><p>'+escape(snapshots)+'</p>'+
    '<div class="controls"><a class="button" href="'+escape(eventHref(other,eventQuery))+'">View '+heading(other).toLowerCase()+'</a>'+
    '<button type="button" id="compare-event">Compare by frequency</button><a class="button" href="#'+active+'">Live chart</a><a class="button" href="#events">Back to events</a></div>'+
    '<p>Measurements and counter increases close in time can suggest a relationship. They do not establish which channel caused an event.</p>'+
    (evidence.length?table(['Channel','Centre frequency','Power before','Power after','Δ power','T3 / T4','Evidence'],
      evidence.map(r=>[r.id??r.type,frequencyLabel(r.frequencyHz),r.before,r.after,r.power,r.t3+' / '+r.t4,r.reason.join(' · ')]),
      i=>historyHref(active,evidence[i].key,null,event.time,'event')):'<p>No channel could be linked from the available samples.</p>');
  $('compare-event').onclick=()=>choosePowerMode('frequency');
}
function renderDiagnostics(info) {
  const rate=value=>value==null?'—':(value/1e6).toLocaleString('en-GB',{maximumFractionDigits:3})+' Mbps';
  const yn=value=>value==null?'—':value?'Yes':'No';
  $('diagnostics-state').textContent=!info.captured ? (info.paused?'Polling paused; no modem snapshot in this session.':'Waiting for the first modem snapshot.') :
    'Last snapshot '+time(info.captured)+' UK'+(info.paused?' · Polling paused':'')+
    (info.unavailable.length?' · Unavailable: '+info.unavailable.join(', '):'');
  const facts=[['DOCSIS',info.docsisVersion],['Modem state',info.state],['Registered',yn(info.registered)],['Uptime',
    info.uptime==null?null:Math.floor(info.uptime/86400)+'d '+Math.floor(info.uptime%86400/3600)+'h '+Math.floor(info.uptime%3600/60)+'m'],
    ['Primary downstream',frequencyLabel(info.primary?.downstream?.frequencyHz)],['Primary upstream',frequencyLabel(info.primary?.upstream?.frequencyHz)]];
  $('modem-facts').innerHTML=facts.map(([label,value])=>'<div><span>'+escape(label)+'</span><strong>'+escape(value)+'</strong></div>').join('');
  $('service-flows').innerHTML='<h3>Provisioned service flows</h3><p>Configured rates from the modem. This is not a speed test.</p>'+
    table(['Direction','Maximum','Reserved minimum','Scheduling'],(info.serviceFlows ?? []).map(f=>[heading(f.direction),rate(f.maxRate),rate(f.minRate),f.schedule]));
  const inventory=Object.entries(status?.current ?? {}).flatMap(([d,rows])=>rows.map(r=>[d,r]));
  $('frequency-inventory').innerHTML=table(['Channel','Direction','Type','Centre','Width','Symbol rate (ksym/s)','FFT','Active subcarriers','First-active field','MER (dB)'],
    inventory.map(([d,r])=>[r.id,heading(d),r.type,frequencyLabel(r.frequencyHz),frequencyLabel(r.widthHz),
      r.symbolRateKsps,r.fftType,r.activeSubcarriers,r.firstActiveRaw,r.mer]),i=>historyHref(inventory[i][0],inventory[i][1].key));
}
async function refresh(wanted, clear=false) {
  dashboardJob?.abort();
  const job = dashboardJob = new AbortController();
  dashboardBusy = true;
  const requests={signal:job.signal};
  const statusRead=request('/api/status',requests).then(result=>{
    if (job.signal.aborted) return;
    status=result;
    live.paused=result.paused;
    liveBadge();
    applyLiveStatus(live.last);
    renderStatus();
    if (signals()) multiChart.setData(chartState={...chartState,...powerSnapshot()});
  }).catch(error=>{
    if (!job.signal.aborted) showError('Collector status unavailable: '+error.message);
  });
  try {
    if (signals()) {
      if(eventQuery && !eventContext) {
        const observation=await request('/api/correlation?'+new URLSearchParams(eventQuery),requests);
        if (job.signal.aborted) return;
        eventContext=observation;
        renderInvestigation();
      }
      await statusRead;
      if (job.signal.aborted) return;
      if (powerMode==='frequency') {
        multiChart.setData(chartState={...chartState,...powerSnapshot()});
        return;
      }
      if (clear) multiChart.setData(chartState={...powerSnapshot(),loading:true},true);
      const pin=powerZoom ?? eventContext;
      const graph=pin ? queryRange(pin.from,pin.to) : rollingRange($('power-range').value,active);
      try {
        const {series,bucketMs,from,to}=await request('/api/power?'+graph.query+'&direction='+active,requests);
        if (!job.signal.aborted) {
          chartState={...powerSnapshot(),snapshot:series,bucketMs,range:{from,to}};
          if (fixedPower()) multiChart.setData(chartState);
          else {
            for (const frame of live.frames ?? []) if (frame.time>=to-15000) appendPower(frame);
            advancePower(collectorNow());
          }
        }
      } catch(error) {
        if (!job.signal.aborted) multiChart.setData(chartState={...chartState,loading:false,error:error.message});
      }
    } else if (active==='history') {
      await statusRead;
      if (job.signal.aborted) return;
      const nextRange=selectedRange();
      const nextCatalogue=await request('/api/channels?'+nextRange.query,requests);
      if (job.signal.aborted) return;
      if (!status) throw Error('Collector status is needed to load history.');
      catalogue=nextCatalogue;
      range=nextRange;
      $('rf-export').href='/api/rf.csv?'+range.query;
      await refreshTimeline(wanted,clear);
    } else if (active==='diagnostics') {
      const [info]=await Promise.all([request('/api/modem',requests),statusRead]);
      if (!job.signal.aborted) renderDiagnostics(info);
    } else if (active==='events') {
      const eventRange=rollingRange($('event-range').value);
      const nextEvents=await request('/api/events?'+eventRange.query,requests);
      if (job.signal.aborted) return;
      const expanded=Array.from($('incidents').querySelectorAll('details[open]'),d=>d.querySelector('summary').textContent);
      eventData=nextEvents;
      $('event-export').href='/api/events.csv?'+eventRange.query;
      options($('severity'),[['','All'],...Array.from(new Set(eventData.events.map(r=>r.priority))).sort().map(v=>[v,v])]);
      renderEvents();
      for (const detail of $('incidents').querySelectorAll('details')) detail.open=expanded.includes(detail.querySelector('summary').textContent);
    }
  } catch(error) {
    if (!job.signal.aborted) showError(error.message);
  } finally {
    await statusRead;
    if (job===dashboardJob) dashboardBusy=false;
  }
}
function metricOptions() {
  const preferred = $('direction').value==='downstream' ? ['power','mer','lock','corrected','uncorrectable'] : ['power','lock','t1','t2','t3','t4'];
  const keys = [...new Set([...preferred,...Object.keys(labels)])];
  options($('metric'),keys.map(k=>[k,labels[k]]));
}
function localInput(ms) {
  const date = new Date(ms);
  return new Date(ms-date.getTimezoneOffset()*60000).toISOString().slice(0,19);
}
const sliderSteps=[.5,1,1.5,2,2.5,3,4,5,6,7,8,9,10,12,15,20,25,30,45,60,90,120,180,240,300,450,600,900];
const presets=[...document.querySelectorAll('[data-interval]')];
$('interval-slider').max=sliderSteps.length-1;
function syncIntervalSlider() {
  const value=$('interval').valueAsNumber;
  const index=sliderSteps.reduce((best,step,i)=>Math.abs(step-value)<Math.abs(sliderSteps[best]-value)?i:best,0);
  const slider=$('interval-slider');
  slider.value=index;
  slider.setAttribute('aria-valuetext',duration(sliderSteps[index]*1000));
  $('interval-preview').textContent=$('interval').validity.valid ? duration(value*1000) : '—';
  for(const preset of presets) preset.setAttribute('aria-pressed',String(Number(preset.dataset.interval)===value));
}
function chooseInterval(value) {
  $('interval').value=value;
  $('settings-form').dataset.dirty='yes';
  syncIntervalSlider();
}
$('interval-slider').addEventListener('input',()=>chooseInterval(sliderSteps[$('interval-slider').valueAsNumber]));
$('interval').addEventListener('input',syncIntervalSlider);
for(const preset of presets) preset.addEventListener('click',()=>chooseInterval(preset.dataset.interval));
syncIntervalSlider();
function resetRange() {
  showError();
  historyPin=null;
  $('history-pin').hidden=true;
  zoom = null;
  lastExtra = {direction:null,keys:[]};
  chartJob?.abort();
  connectLive();
  refresh(undefined,true);
}
$('from').value = localInput(Date.now()-86400000);
$('to').value = localInput(Date.now());
$('range').addEventListener('change',()=>{
  for (const label of document.querySelectorAll('.custom')) label.hidden = $('range').value!=='custom';
  resetRange();
});
$('direction').addEventListener('change',()=>{metricOptions();connectLive();refreshTimeline(undefined,true);});
for (const id of ['from','to']) $(id).addEventListener('change',resetRange);
for (const id of ['channel','metric']) $(id).addEventListener('change',()=>refreshTimeline(undefined,true));
function syncRoute() {
  const [slug,query] = location.hash.slice(1).split('?');
  active=['upstream','history','events','diagnostics','settings'].includes(slug) ? slug : 'downstream';
  const titles={downstream:'Downstream',upstream:'Upstream',history:'Channel History',events:'Events',diagnostics:'Diagnostics',settings:'Settings'};
  $('heading').textContent=titles[active];
  document.querySelectorAll('[data-view]').forEach(panel=>{panel.hidden=!panel.dataset.view.split(' ').includes(active);});
  for (const link of document.querySelectorAll('.app-nav a')) {
    if (link.hash==='#'+active) link.setAttribute('aria-current','page');
    else link.removeAttribute('aria-current');
  }
  showError();
  chartJob?.abort();
  const route=new URLSearchParams(query);
  eventQuery=null;
  eventContext=null;
  powerZoom=null;
  historyPin=null;
  if (signals()) {
    if (route.get('event')) eventQuery={event:route.get('event')};
    else if (route.get('at')) eventQuery={at:route.get('at')};
    if (eventQuery) {
      powerMode='time';
      multiChart.setMode('time');
    }
    renderInvestigation();
    $('power-kicker').textContent=titles[active]+' signal';
    $('power-title').firstChild.textContent=(active==='upstream'?'US':'DS')+' Power ';
    if (status) renderStatus();
    multiChart.setData(chartState={...powerSnapshot(),loading:powerMode==='time'},true);
  }
  let key;
  if (active==='history') {
    zoom=null;
    if ($('range').value==='pinned') $('range').value='86400';
    $('history-pin').hidden=true;
    lastExtra={direction:null,keys:[]};
    if (['upstream','downstream'].includes(route.get('direction'))) {
      $('direction').value=route.get('direction');
      metricOptions();
      $('metric').value='power';
      key=route.get('key');
      const at=Number(route.get('at'));
      const note=$('history-pin');
      if (Number.isSafeInteger(at) && at>0 && at<8640000000000000-120000) {
        historyPin={at,kind:route.get('kind')};
        note.hidden=false;
        note.textContent=(historyPin.kind==='event'?'Event: ':'Selected reading: ')+time(at)+' UK';
        if (historyPin.kind==='event') {
          const back=document.createElement('a');
          back.href=eventHref($('direction').value,route.get('event')?{event:route.get('event')}:{at});
          back.textContent=' · Back to investigation';
          note.append(back);
        }
      } else note.hidden=true;
      const span=route.get('span');
      if (historyPin) {
        $('range').value='pinned';
        for(const label of document.querySelectorAll('.custom')) label.hidden=true;
      } else if ([...$('range').options].some(o=>o.value===span && !o.disabled && span!=='custom')) {
        $('range').value=span;
        for (const label of document.querySelectorAll('.custom')) label.hidden=true;
      }
    }
  }
  connectLive();
  refresh(key,true);
}
window.addEventListener('hashchange',()=>{
  syncRoute();
  window.scrollTo(0,0);
  if (location.hash.startsWith('#history?')) $('heading').focus({preventScroll:true});
});
function choosePowerMode(next) {
  if (next===powerMode) return;
  powerMode=next;
  multiChart.setMode(next);
  refresh(undefined,true);
}
$('power-time').addEventListener('click',()=>choosePowerMode('time'));
$('power-frequency').addEventListener('click',()=>choosePowerMode('frequency'));
$('power-range').addEventListener('change',()=>{
  if(eventQuery) {location.hash='#'+active;return;}
  powerZoom=null;
  refresh(undefined,true);
});
$('event-range').addEventListener('change',()=>{showError();refresh();});
$('severity').addEventListener('change',renderEvents);
$('refresh').addEventListener('click',()=>{showError();refresh();});
$('polling-switch').addEventListener('change',async event=>{
  const toggle=event.currentTarget;
  const result=$('polling-result');
  const paused=!toggle.checked;
  toggle.disabled=true;
  toggle.setAttribute('aria-busy','true');
  try {
    await request('/api/capture',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paused})});
    live.paused=paused;
    if(status) status.paused=paused;
    result.textContent=paused?'Polling paused.':'Polling resumed.';
    refresh();
  } catch(error) {
    toggle.checked=!isPaused();
    result.textContent=error.message;
  } finally {
    toggle.removeAttribute('aria-busy');
    toggle.disabled=false;
    if(status) renderStatus();
  }
});
$('settings-form').addEventListener('input',()=>{$('settings-form').dataset.dirty='yes';});
$('settings-form').addEventListener('submit',async event=>{
  event.preventDefault();
  const result = $('settings-result');
  const interval=$('interval').valueAsNumber;
  try {
    await request('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({interval,retention:$('retention').valueAsNumber})});
    delete $('settings-form').dataset.dirty;
    result.textContent = 'Settings saved.';
    refresh();
  } catch (error) {result.textContent = error.message;}
});
metricOptions();
syncRoute();
setInterval(()=>{if (!document.hidden && !dashboardBusy && !chartBusy) refresh();},30000);

setInterval(()=>{
  if (document.hidden || !live.direction) return;
  liveBadge();
  if (!live.sample || collectorNow()-live.sample.serverTime<1000) return;
  if (signals() && powerMode==='time') advancePower(collectorNow());
  else if(needsLiveHistory()) advanceDetail(collectorNow());
},1000);
