const $ = id => document.getElementById(id);
const number = new Intl.NumberFormat('en-GB',{maximumFractionDigits:2});
const formatTime = options => new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',...options});
const clock = formatTime({hour:'2-digit',minute:'2-digit'});
const seconds = formatTime({hour:'2-digit',minute:'2-digit',second:'2-digit'});
const stamp = formatTime({day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
const exact = formatTime({day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',second:'2-digit',fractionalSecondDigits:3,timeZoneName:'short'});
const hues = [219,16,174,271,44,325,198,101,350,150,29,235,58,286,186,6,252];
const svgNS = 'http://www.w3.org/2000/svg';

function frequencyMHz(value) {
  const m = String(value ?? '').trim().match(/^(\d+(?:\.\d+)?)\s*(hz|khz|mhz)?$/i);
  if (!m) return null;
  const mhz = Number(m[1])*({mhz:1,khz:.001,hz:.000001}[m[2]?.toLowerCase() ?? 'hz']);
  return Number.isFinite(mhz) && mhz>=1 ? mhz : null;
}
const metadata = key => {
  const [type,id,frequency] = JSON.parse(key);
  return {key,type:type.replaceAll('_','-'),id:id ?? '—',mhz:frequencyMHz(frequency)};
};
const db = value => value==null ? '—' : number.format(value)+' dBmV';
const title = channel => 'Ch '+channel.id+' · '+channel.type;
const distinctSort = (a,b) => String(a.id).localeCompare(String(b.id),'en',{numeric:true}) || a.type.localeCompare(b.type) || (a.mhz ?? 0)-(b.mhz ?? 0);
const distance = (x,y,point) => Math.hypot(point.x-x,point.y-y);
function lowerBound(rows,x) {
  let lo=0,hi=rows.length;
  while(lo<hi) {
    const mid=(lo+hi)>>1;
    if (rows[mid].time<x) lo=mid+1;
    else hi=mid;
  }
  return lo;
}
function niceStep(raw) {
  const scale=10**Math.floor(Math.log10(raw));
  return ([1,2,2.5,5,10].find(n=>n*scale>=raw) ?? 10)*scale;
}
function swatch(colour) {
  const svg=document.createElementNS(svgNS,'svg');
  const dot=document.createElementNS(svgNS,'circle');
  svg.setAttribute('viewBox','0 0 12 12');
  svg.setAttribute('aria-hidden','true');
  dot.setAttribute('cx','6');
  dot.setAttribute('cy','6');
  dot.setAttribute('r','4');
  dot.setAttribute('fill',colour);
  svg.append(dot);
  return svg;
}

export function powerChart(href,onZoom) {
  const canvas=$('power-plot'), ctx=canvas.getContext('2d');
  let data={}, shown=[], plotted=[], focus, geometry, mode='time';
  let readoutKey, chips=[], queued=false, drag, blockClick=false;
  const holdAfter=()=>Math.max(data.bucketMs*3,data.cadenceMs*3,2000);
  function queueDraw() {
    if (queued) return;
    queued=true;
    requestAnimationFrame(()=>{queued=false;draw();});
  }
  function palette(index) {
    const dark=document.documentElement.dataset.theme==='dark';
    return 'hsl('+hues[index%hues.length]+' '+(index>=hues.length?62:77)+'% '+(dark ? (index>=hues.length?77:66) : (index>=hues.length?36:43))+'%)';
  }
  function chartRows() {
    return mode==='time' ? (data.snapshot ?? []).flatMap(entry=>{
      const latest=entry.points.findLast(p=>Number.isFinite(p.power));
      return latest ? [{...metadata(entry.key),points:entry.points,latest:latest.power}] : [];
    }) : data.compare ? data.compare.rows.filter(row=>Number.isFinite(row.before) || Number.isFinite(row.after))
      .map(row=>({...metadata(row.key),mhz:row.frequencyHz==null?null:row.frequencyHz/1e6,
        latest:row.after ?? row.before,before:row.before,after:row.after})) :
      (data.current ?? []).filter(row=>Number.isFinite(row.power)).map(row=>({...metadata(row.key),
        mhz:row.frequencyHz==null?frequencyMHz(row.frequency):row.frequencyHz/1e6,latest:row.power,after:row.power}));
  }
  function render(reset=false) {
    if(reset) { focus=null; readoutKey=null; }
    const filter=$('power-filter').value;
    const rows=chartRows().sort(distinctSort).map((ch,i)=>({...ch,index:i}));
    if (mode==='frequency') rows.sort((a,b)=>(a.mhz ?? Infinity)-(b.mhz ?? Infinity) || distinctSort(a,b));
    shown=rows.filter(ch=>filter==='all' || (filter==='ofdm')===/OFDM/i.test(ch.type));
    plotted=mode==='time' ? shown : shown.filter(ch=>ch.mhz!=null);
    const missing=shown.length-plotted.length;
    if (focus && !plotted.some(ch=>ch.key===focus.key)) focus=null;
    const label=$('power-state');
    if (data.error && mode==='time') label.textContent='Power history unavailable: '+data.error;
    else if (data.loading && mode==='time') label.textContent='Loading power history…';
    else if (mode==='time') label.textContent=shown.length+' channels · '+(data.bucketMs===1?'Every captured reading':'Latest reading per interval')+' · UK local time';
    else label.textContent=plotted.length+' of '+shown.length+' channels have a reported centre frequency'+
      (data.compare?' · Before / after event':data.captured?' · Captured '+stamp.format(data.captured):'')+(data.sourceError&&!data.compare?' · Last successful poll':'');
    const values=shown.map(ch=>ch.latest).filter(Number.isFinite);
    const low=values.length ? Math.min(...values) : null, high=values.length ? Math.max(...values) : null;
    const stats=[['Channels',shown.length],['Lowest level',db(low)],['Highest level',db(high)],['Level spread',low==null?'—':number.format(high-low)+' dB']];
    $('power-stats').replaceChildren(...stats.map(([label,value])=>{
      const cell=document.createElement('div'), key=document.createElement('span'), val=document.createElement('strong');
      key.textContent=label; val.textContent=value; cell.append(key,val); return cell;
    }));
    $('power-help').textContent=mode==='time' ?
      'Drag across time to zoom. Click a trace to open that channel around the selected reading. Faded segments hold the last measured value.' :
      (data.compare ? 'Hollow marks show before, solid marks after. ' : '')+
      'Each mark is one measurement at a reported channel centre. '+
      (plotted.length<=16?'The connecting line guides the eye; there are no measured values between channels. ':'')+
      'Click a mark to open its time history.'+
      (missing?' '+missing+' '+(missing===1?'channel has':'channels have')+' no reported frequency and can still be opened below.':'');
    if (shown.length!==chips.length || shown.some((ch,i)=>ch.key!==chips[i].dataset.channel)) {
      const oldFocus = $('power-legend').contains(document.activeElement) && document.activeElement.dataset.channel;
      chips=shown.map(ch=>{
        const anchor=document.createElement('a'), name=document.createElement('span');
        anchor.className='power-chip'; anchor.dataset.channel=ch.key;
        name.textContent=title(ch);
        anchor.append(swatch(palette(ch.index)),name,document.createElement('strong'));
        return anchor;
      });
      $('power-legend').replaceChildren(...chips);
      if (oldFocus) chips.find(link=>link.dataset.channel===oldFocus)?.focus({preventScroll:true});
    }
    shown.forEach((ch,i)=>{
      const anchor=chips[i];
      const link=href(ch.key), colour=palette(ch.index);
      if (anchor.getAttribute('href')!==link) anchor.href=link;
      anchor.title='Open history for '+title(ch)+(ch.mhz==null?'':' at '+number.format(ch.mhz)+' MHz');
      anchor.querySelector('circle').setAttribute('fill',colour);
      const value=db(ch.latest)+(mode==='frequency' && ch.mhz==null?' · No MHz':'');
      if (mode==='frequency') {
        const caption=title(ch)+(ch.mhz==null?'':' · '+number.format(ch.mhz)+' MHz');
        if(anchor.children[1].textContent!==caption) anchor.children[1].textContent=caption;
      } else if(anchor.children[1].textContent!==title(ch)) anchor.children[1].textContent=title(ch);
      if (anchor.lastChild.textContent!==value) anchor.lastChild.textContent=value;
    });
    const empty=$('power-empty');
    empty.hidden=plotted.length>0;
    empty.textContent=mode==='time' && data.loading?'Loading power readings…' :
      mode==='frequency' && shown.length?'No reported frequencies for the selected channels.':'No power measurements in this view.';
    const nav=$('signal-navigation'), view=data.range;
    $('power-range-label').hidden=mode!=='time'||Number.isFinite(data.marker);
    nav.hidden=mode!=='time';
    $('signal-window').textContent=view ? (data.frozen?'Pinned window · ':'Following · ')+
      (view.to-view.from>86400000?stamp:seconds).format(view.from)+' – '+(view.to-view.from>86400000?stamp:seconds).format(view.to)+' UK' : '';
    $('signal-in').disabled=!view || view.to-view.from<=2000;
    $('signal-out').disabled=!view || !data.zoomed;
    $('signal-reset').disabled=!data.zoomed;
    queueDraw();
  }
  function draw() {
    const w=canvas.clientWidth,h=canvas.clientHeight,dpr=devicePixelRatio || 1;
    if (!w || !h) { geometry=null; return; }
    const cw=Math.round(w*dpr),ch=Math.round(h*dpr);
    if (canvas.width!==cw) canvas.width=cw;
    if (canvas.height!==ch) canvas.height=ch;
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,w,h);
    geometry=null;
    const left=51,right=w-18,top=mode==='frequency'?31:24,bottom=h-37;
    const markerOnly=mode==='time' && Number.isFinite(data.marker) && data.range;
    if (w<110 || (!plotted.length && !markerOnly) || (mode==='time' && !data.range)) { updateReadout(null); return; }
    let min=Infinity,max=-Infinity;
    for(const channel of plotted) {
      const values=mode==='time' ? channel.points.map(p=>p.power) : [channel.before,channel.after];
      for (const v of values) if(Number.isFinite(v)) {min=Math.min(min,v);max=Math.max(max,v);}
    }
    const hasPower=Number.isFinite(min);
    if (!hasPower) {
      if (!markerOnly) { updateReadout(null); return; }
      min=0;max=1;
    }
    const range = data.range;
    const first=mode==='time'?range.from:Math.min(...plotted.map(ch=>ch.mhz));
    const last=mode==='time'?range.to:Math.max(...plotted.map(ch=>ch.mhz));
    const pad=mode==='time'?0:Math.max((last-first)*.075,1);
    const loX=first-pad,hiX=last+pad;
    const step=niceStep(Math.max(max-min,1)/5);
    const loY=Math.floor((min-step*.22)/step)*step,hiY=Math.ceil((max+step*.22)/step)*step;
    const x=t=>left+(t-loX)/(hiX-loX)*(right-left);
    const y=v=>bottom-(v-loY)/(hiY-loY)*(bottom-top);
    const line=(ax,ay,bx,by)=>{ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();};
    const styles=getComputedStyle(document.documentElement);
    const colour=name=>styles.getPropertyValue('--'+name).trim();
    ctx.font='11px system-ui';
    ctx.fillStyle=colour('muted'); ctx.strokeStyle=colour('border');
    if (hasPower) ctx.fillText('dBmV',left,12);
    for(let i=0;hasPower && i<=Math.round((hiY-loY)/step);i++) {
      const v=loY+i*step;
      ctx.setLineDash(Math.abs(v)<step/100 ? [] : [3,3]);
      line(left,y(v),right,y(v));
      ctx.textAlign='right';ctx.fillText(number.format(Math.abs(v)<step/100?0:v),left-7,y(v)+4);
    }
    ctx.textAlign='center';ctx.setLineDash([3,3]);
    const ticks=w<520?4:w<900?6:8;
    const formatter=hiX-loX<=15*60000?seconds:hiX-loX<86400000?clock:stamp;
    const dx=niceStep((hiX-loX)/(ticks-1));
    const axisTicks=mode==='time' ? Array.from({length:ticks},(_,i)=>loX+(hiX-loX)*i/(ticks-1)) :
      Array.from({length:ticks+1},(_,i)=>(Math.ceil(loX/dx)+i)*dx).filter(f=>f<=hiX);
    for(const t of axisTicks) {
      const px=x(t);
      const text=mode==='time'?formatter.format(t):number.format(Math.round(t*10)/10);
      const half=ctx.measureText(text).width/2;
      line(px,top,px,bottom);
      ctx.fillText(text,Math.max(half,Math.min(w-half,px)),bottom+17);
    }
    ctx.setLineDash([]);
    ctx.fillText(mode==='time'?'Time (UK)':'Frequency (MHz)',(left+right)/2,h-2);
    ctx.textAlign='start';
    if (mode==='frequency') {
      const guide=(field,dash)=>{
        if (plotted.length>16) return;
        const rows=plotted.filter(ch=>Number.isFinite(ch[field])).sort((a,b)=>a.mhz-b.mhz);
        ctx.strokeStyle=colour('freq-guide');ctx.globalAlpha=.53;ctx.setLineDash(dash);ctx.beginPath();
        rows.forEach((ch,i)=>i?ctx.lineTo(x(ch.mhz),y(ch[field])):ctx.moveTo(x(ch.mhz),y(ch[field])));
        ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
      };
      guide('before',[4,4]);guide('after',[]);
    }
    const drawChannel=ch=>{
      const ink=palette(ch.index);
      ctx.strokeStyle=ink;ctx.fillStyle=ink;
      const alpha=focus ? (focus.key===ch.key ? 1 : .25) : .9;
      ctx.globalAlpha=alpha;
      ctx.lineWidth=focus?.key===ch.key ? 2.5 : 1.35;
      if(mode==='frequency') {
        const px=x(ch.mhz);
        if (Number.isFinite(ch.before)) {
          ctx.beginPath();ctx.arc(px,y(ch.before),7,0,2*Math.PI);ctx.fillStyle=colour('plot-bg');ctx.fill();
          ctx.lineWidth=2;ctx.stroke();
        }
        if (Number.isFinite(ch.after)) {
          ctx.beginPath();ctx.arc(px,y(ch.after),5,0,2*Math.PI);ctx.fillStyle=ink;ctx.fill();
        }
        if (plotted.length<=10) {
          const label='Ch '+ch.id+(w>=760?' · '+number.format(ch.latest):'');
          const half=ctx.measureText(label).width/2;
          ctx.font='600 11px system-ui';ctx.textAlign='center';ctx.fillStyle=colour('text');
          const py=y(Math.max(ch.before ?? -Infinity,ch.after ?? -Infinity));
          ctx.fillText(label,Math.max(half,Math.min(w-half,px)),py-12);
          ctx.textAlign='start';ctx.font='11px system-ui';
        }
      } else {
        const gap=holdAfter();
        const held=[];
        let last;
        let nullAfter=false;
        ctx.beginPath();
        for(const point of ch.points) {
          if(!Number.isFinite(point.power)) { nullAfter=true;continue; }
          const px=x(point.time),py=y(point.power);
          if(last) {
            if(nullAfter || point.time-last.time>gap) {
              held.push([last.x,px,last.y]);
              ctx.moveTo(px,last.y);
            } else ctx.lineTo(px,last.y);
            ctx.lineTo(px,py);
          } else {
            ctx.moveTo(px,py);
            ctx.fillRect(px-1.5,py-1.5,3,3);
          }
          nullAfter=false;
          last={time:point.time,x:px,y:py};
        }
        if (last) {
          const liveEdge=Math.min(right,x(last.time+Math.max(data.bucketMs,data.cadenceMs)));
          if (nullAfter) held.push([last.x,right,last.y]);
          else {
            ctx.lineTo(liveEdge,last.y);
            if (liveEdge<right) held.push([liveEdge,right,last.y]);
          }
          ctx.fillRect(last.x-1.5,last.y-1.5,3,3);
        }
        ctx.stroke();
        if (held.length) {
          ctx.globalAlpha=alpha*.42;
          ctx.beginPath();
          for (const [from,to,y] of held) {ctx.moveTo(from,y);ctx.lineTo(to,y);}
          ctx.stroke();
        }
      }
      ctx.globalAlpha=1;ctx.lineWidth=1;
    };
    for (const channel of plotted) if(channel.key!==focus?.key) drawChannel(channel);
    const selected=plotted.find(channel=>channel.key===focus?.key);
    if (selected) drawChannel(selected);
    if (mode==='time' && data.marker>=loX && data.marker<=hiX) {
      const px=x(data.marker);
      ctx.strokeStyle=colour('event-line');ctx.fillStyle=colour('event-line');ctx.setLineDash([5,4]);
      line(px,top,px,bottom);ctx.setLineDash([]);
      ctx.fillText('Event',Math.min(right-33,px+5),top+12);
    }
    if (drag) {
      ctx.fillStyle=colour('select');
      ctx.fillRect(Math.min(drag.start,drag.end),top,Math.abs(drag.start-drag.end),bottom-top);
    }
    if (selected && focus.xValue>=loX && focus.xValue<=hiX) {
      const px=x(focus.xValue),py=y(focus.power);
      ctx.strokeStyle=colour('muted');ctx.setLineDash([4,4]);line(px,top,px,bottom);ctx.setLineDash([]);
      ctx.fillStyle=palette(selected.index);ctx.beginPath();ctx.arc(px,py,4,0,2*Math.PI);ctx.fill();
      updateReadout(selected);
    } else updateReadout(null);
    geometry={x,y,left,right,top,bottom,unmap:px=>loX+(px-left)/(right-left)*(hiX-loX)};
  }
  function updateReadout(channel) {
    const description=channel && focus ? title(channel)+' · '+db(focus.power)+' · '+
      (mode==='time'?(focus.held?'Last measured ':'')+exact.format(focus.xValue):number.format(channel.mhz)+' MHz'+
      (focus.phase?' · '+focus.phase:'')) : '';
    if ($('power-inspect').textContent!==description) $('power-inspect').textContent=description;
    const key=channel && href(channel.key,focus.time);
    if (readoutKey!==key) {
      readoutKey=key;
      if (channel) $('power-open').href=key;
      $('power-open').hidden=!channel;
    }
  }
  function hit(event) {
    if(!geometry)return null;
    const rect=canvas.getBoundingClientRect();
    const px=event.clientX-rect.left,py=event.clientY-rect.top;
    const {x,y,unmap,left,right,top,bottom}=geometry;
    if(px<left-8 || px>right+8 || py<top-8 || py>bottom+8)return null;
    let nearest=null, best=Infinity;
    function consider(ch,value,power,horizontal=false,held=false,phase,time=value) {
      if(!Number.isFinite(power))return;
      const score=horizontal ? Math.abs(py-y(power)) : distance(px,py,{x:x(value),y:y(power)});
      if (score<best) { best=score;nearest={key:ch.key,xValue:value,power,held,phase,time}; }
    }
    for (const ch of plotted) {
      if (mode==='frequency') {
        consider(ch,ch.mhz,ch.after,false,false,data.compare?'After':null,data.compare?.after ?? data.captured ?? null);
        consider(ch,ch.mhz,ch.before,false,false,'Before',data.compare?.before ?? null);
        continue;
      }
      const i=lowerBound(ch.points,unmap(px));
      let a=ch.points[i-1];
      const crossedNull=a && !Number.isFinite(a.power);
      while (a && !Number.isFinite(a.power)) {
        const j=lowerBound(ch.points,a.time)-1;
        a=ch.points[j];
      }
      const b=ch.points[i];
      for(const p of [a,b]) if(p) consider(ch,p.time,p.power);
      if(a) {
        const held=crossedNull || (b ? !Number.isFinite(b.power) || b.time-a.time>holdAfter() :
          unmap(px)-a.time>Math.max(data.bucketMs,data.cadenceMs));
        consider(ch,a.time,a.power,true,held);
      }
    }
    return best<(event.pointerType==='touch'?23:13)?nearest:null;
  }
  canvas.addEventListener('pointermove',event=>{
    if (drag?.id===event.pointerId && geometry) {
      drag.end=pointX(event);
      queueDraw();
      return;
    }
    if(event.pointerType==='touch')return;
    focus=hit(event);
    canvas.classList.toggle('is-clickable',Boolean(focus));
    queueDraw();
  });
  canvas.addEventListener('click',event=>{
    if (blockClick) {blockClick=false;return;}
    const selected=hit(event);
    if(!selected)return;
    if(event.pointerType==='touch' && focus?.key!==selected.key) {focus=selected;queueDraw();return;}
    location.hash=href(selected.key,selected.time);
  });
  const pointX=event=>Math.max(geometry.left,Math.min(geometry.right,event.clientX-canvas.getBoundingClientRect().left));
  canvas.addEventListener('pointerdown',event=>{
    blockClick=false;
    if(mode!=='time' || !geometry || !event.isPrimary || event.button!==0) return;
    const x=pointX(event);
    drag={id:event.pointerId,start:x,end:x,unmap:geometry.unmap};
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener('pointerup',event=>{
    if (drag?.id!==event.pointerId || !geometry) return;
    const {start,unmap}=drag,end=pointX(event);
    drag=null;
    if (Math.abs(end-start)>=12) {
      blockClick=true;
      const from=Math.round(unmap(Math.min(start,end))), to=Math.round(unmap(Math.max(start,end)));
      if (to-from>=2000) onZoom({from,to});
    }
    queueDraw();
  });
  canvas.addEventListener('lostpointercapture',()=>{drag=null;queueDraw();});
  canvas.addEventListener('dblclick',event=>{
    if (mode!=='time' || !geometry || hit(event)) return;
    const span=data.range.to-data.range.from;
    if(span<=2000)return;
    const size=Math.max(2000,Math.round(span/2)), centre=geometry.unmap(pointX(event));
    const from=Math.round(Math.min(data.range.to-size,Math.max(data.range.from,centre-size/2)));
    onZoom({from,to:from+size});
  });
  $('signal-in').onclick=()=>{
    const view=data.range;
    if (!view) return;
    const width=Math.max(2000,Math.round((view.to-view.from)/2));
    const around=focus?.time ?? (view.to+view.from)/2;
    const from=Math.round(Math.min(view.to-width,Math.max(view.from,around-width/2)));
    onZoom({from,to:from+width});
  };
  $('signal-out').onclick=()=>{
    const view=data.range;
    if (!view) return;
    const extra=Math.round((view.to-view.from)/2);
    onZoom({from:view.from-extra,to:view.to+extra});
  };
  $('signal-reset').onclick=()=>onZoom(null);
  new ResizeObserver(draw).observe(canvas);
  window.addEventListener('hub5-themechange',()=>render());
  $('power-filter').addEventListener('change',()=>render(true));
  return {
    setMode(next) {
      mode=next;
      $('power-time').setAttribute('aria-pressed',String(next==='time'));
      $('power-frequency').setAttribute('aria-pressed',String(next==='frequency'));
      $('power-range-label').hidden=next!=='time';
      $('power-key').hidden=next!=='time';
      render(true);
    },
    setData(next,reset=false) {data=next;render(reset);}
  };
}
