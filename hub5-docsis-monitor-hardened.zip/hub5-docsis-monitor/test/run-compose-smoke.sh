#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
# A unique project owns this database and both ports bind to loopback.
project="hub5-smoke-$$"
export BIND_IP=127.0.0.1 WEB_PORT="${WEB_PORT:-13080}" MOCK_WEB_PORT="${MOCK_WEB_PORT:-13081}" HUB_URL=http://mock-hub:8080
export MONITOR_TEST_URL="http://127.0.0.1:$WEB_PORT" MOCK_TEST_URL="http://127.0.0.1:$MOCK_WEB_PORT"
stack() { docker compose -p "$project" -f compose.yaml -f test/compose.smoke.yaml "$@"; }
cleanup() { stack down -v; }
trap cleanup EXIT
stack config -q
stack build monitor
stack run --rm --no-deps monitor node /test/legacy-db.mjs seed
stack up -d --wait --wait-timeout 75
node test/smoke.mjs
stack restart monitor
stack exec -T monitor node /test/legacy-db.mjs verify
node test/verify-restart.mjs
