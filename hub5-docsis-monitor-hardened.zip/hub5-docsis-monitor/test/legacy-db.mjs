import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';

const schema = `
  CREATE TABLE settings (id INTEGER PRIMARY KEY, interval INTEGER, retention INTEGER);
  CREATE TABLE source_status (source TEXT PRIMARY KEY, attempted INTEGER, good INTEGER, error TEXT);
  CREATE TABLE samples (direction TEXT, time INTEGER, key TEXT, data TEXT, PRIMARY KEY(direction,time,key));
  CREATE INDEX channel_history ON samples(direction,key,time);
  CREATE TABLE ranging (time INTEGER PRIMARY KEY, counts TEXT);
  CREATE TABLE events (id TEXT PRIMARY KEY, time INTEGER, priority TEXT, message TEXT);
  CREATE INDEX event_time ON events(time);
`;
const db = new DatabaseSync('/app/data/history.sqlite');
const legacy = [
  ['downstream','["SC-QAM",1,123000000]',-2],
  ['downstream','["OFDM",9,400000000]',-7],
  ['upstream','["SC-QAM",3,24000000]',45],
  ['upstream','["OFDMA",8,37000000]',40]
];
const definitions = db => db.prepare('SELECT type,name,sql FROM sqlite_schema ORDER BY type,name').all();
if (process.argv[2]==='seed') {
  db.exec(schema);
  db.exec("INSERT INTO settings VALUES (1,60,90)");
  const when = Date.now()-600000;
  const insert = db.prepare('INSERT INTO samples VALUES(?,?,?,?)');
  for (const [direction,key,power] of legacy) {
    const [type,id,frequency] = JSON.parse(key);
    const scale=id===9?10:1;
    const raw=id===9?{channelId:id,channelType:'ofdm',fftType:'4K',numberOfActiveSubCarriers:2400,
      firstActiveSubcarrier:808,channelWidth:124000000}:{channelId:id};
    const row = {key,id,type,frequency,power:power*scale,mer:37*scale,lock:1,corrected:22,raw,delta:{corrected:3},reset:[]};
    insert.run(direction,when,key,JSON.stringify(row));
    insert.run(direction,when+1000,key,JSON.stringify({...row,power:(power+1)*scale}));
  }
  db.prepare('INSERT INTO events VALUES(?,?,?,?)').run('legacy-event',when,'notice','Legacy event 00:11:22:33:44:55');
  db.prepare('INSERT INTO events VALUES(?,?,?,?)').run('logged-channel',when+500,'warning','US Chan ID: 8; T3 time-out');
  db.prepare('INSERT INTO events VALUES(?,?,?,?)').run('ambiguous-channel',when+500,'warning','Timeout on upstream channel 8');
} else {
  const empty = new DatabaseSync(':memory:');
  empty.exec(schema);
  assert.deepEqual(definitions(db),definitions(empty),'SQLite schema changed');
  assert.equal(db.prepare("SELECT interval, typeof(interval) AS storage FROM settings WHERE id=1").get().interval,0.5);
  assert.equal(db.prepare("SELECT typeof(interval) AS storage FROM settings WHERE id=1").get().storage,'real');
  assert.equal(db.prepare("SELECT count(*) AS n FROM events WHERE id='legacy-event'").get().n,1);
  const stored=db.prepare("SELECT message FROM events WHERE message LIKE 'Synthetic diagnostic%'").all();
  assert.equal(stored.length,1,'Events differing only in removed identifiers should deduplicate');
  assert.doesNotMatch(stored[0].message,/192\.0\.2\.71|2001:db8|02:00:00|synthetic private value/i);
  assert.equal(db.prepare("SELECT count(*) AS n FROM samples WHERE json_extract(data,'$.raw.subscriberIdentifier') IS NOT NULL").get().n,0);
  for (const [direction,key,power] of legacy) {
    const first = db.prepare('SELECT data FROM samples WHERE direction=? AND key=? ORDER BY time LIMIT 1').get(direction,key);
    assert.equal(JSON.parse(first.data).power,JSON.parse(key)[1]===9?power*10:power,'Legacy sample was changed');
  }
  assert.equal(db.prepare('PRAGMA quick_check').get().quick_check,'ok');
  console.log('Original schema, original rows, 500 ms setting and SQLite integrity verified.');
}
