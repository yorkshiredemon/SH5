import http from 'node:http';

const stats = {downstream:[],upstream:[],eventlog:[]};
const active = {downstream:0,upstream:0,eventlog:0};
let overlap = 0;
let upstreamDelay = 80;
const started=Date.now();
const inventory={
  'state_':{cablemodem:{docsisVersion:'3.1',status:'operational',upTime:172800,serialNumber:'should-not-appear'}},
  registration:{registration:{registrationComplete:true,downstreamLocked:true}},
  serviceflows:{serviceFlows:[{serviceFlow:{direction:'upstream',maxTrafficRate:100000000}}]},
  'downstream/primary_':{channel:{channelId:1,frequency:123000000}},
  'upstream/primary_':{channel:{channelId:3,frequency:24000000}}
};
http.createServer((req,res)=>{
  const source = req.url.replace('/rest/v1/cablemodem/','').replace(/^\//,'');
  res.setHeader('Content-Type','application/json');
  if (source==='stats') return res.end(JSON.stringify({stats,overlap}));
  if (source==='slow') { upstreamDelay=720; return res.end('{}'); }
  if (source==='pause') { upstreamDelay=4200; return res.end('{}'); }
  if (source==='normal') { upstreamDelay=80; return res.end('{}'); }
  if (Object.hasOwn(inventory,source)) return res.end(JSON.stringify(inventory[source]));
  if (!Object.hasOwn(stats,source)) { res.writeHead(404); return res.end('{}'); }
  stats[source].push(Date.now());
  if (active[source]++) overlap++;
  setTimeout(()=>{
    active[source]--;
    const index = stats[source].length;
    const channel = (channelId, channelType, frequency) => ({
      channelId, channelType, frequency, locked:true, powerLevel:channelId+index/100, snr:39,
      corrected:index*10, uncorrectable:index, t3:0, subscriberIdentifier:'synthetic-private-rf-value'
    });
    const logTime=new Date(started+5000).toISOString();
    res.end(JSON.stringify(source==='eventlog' ? {eventlog:[
      {time:logTime,priority:'warning',message:'US Chan ID: 3; T3 time-out'},
      ...['02:00:00:00:00:01','02:00:00:00:00:02'].map(mac=>({time:logTime,priority:'notice',
        message:'Synthetic diagnostic at 192.0.2.71:3000 and [2001:db8::1]; CM-MAC='+mac+'; UserName="synthetic private value"'}))
    ]} :
      {[source]:{channels:source==='downstream' ?
        [channel(1,'SC-QAM',123000000),channel(2,'OFDM',300000000)] :
        [channel(3,'SC-QAM',24000000),channel(4,'OFDMA',38000000)]}}));
  },source==='upstream' ? upstreamDelay : source==='eventlog' ? 1200 : 140);
}).listen(8080,'0.0.0.0');
