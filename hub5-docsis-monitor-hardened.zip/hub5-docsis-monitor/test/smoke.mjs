import assert from 'node:assert/strict';
import http from 'node:http';
import {setTimeout as sleep} from 'node:timers/promises';

const base = process.env.MONITOR_TEST_URL ?? 'http://127.0.0.1:13080';
const mock = process.env.MOCK_TEST_URL ?? 'http://127.0.0.1:13081';
const get = async (path,options) => {
  const res=await fetch(base+path,options);
  assert.equal(res.status,200,path);
  return res.json();
};
const select = interval => get('/api/settings',{method:'POST',headers:{origin:base,'content-type':'application/json'},
  body:JSON.stringify({interval,retention:90})});
const stats = async () => (await fetch(mock+'/stats')).json();
async function readLive(direction,count) {
  const signal=AbortSignal.timeout(7000);
  const response=await fetch(base+'/api/live?direction='+direction,{signal});
  assert.equal(response.status,200);
  assert.match(response.headers.get('content-type'),/^text\/event-stream/);
  const reader=response.body.getReader(), decoder=new TextDecoder();
  let pending='';
  const frames=[];
  try {
    while(frames.length<count) {
      const {done,value}=await reader.read();
      assert.equal(done,false,'Live stream closed early');
      pending+=decoder.decode(value,{stream:true});
      let split;
      while((split=pending.indexOf('\n\n'))!==-1) {
        const block=pending.slice(0,split);
        pending=pending.slice(split+2);
        if(block.startsWith('event: sample\n')) {
          const data=JSON.parse(block.split('\ndata: ')[1]);
          if (data.cadenceMs===500) frames.push(data);
        }
      }
    }
    return frames;
  } finally {await reader.cancel();}
}
const bounds = new URLSearchParams({from:Date.now()-3600000,to:Date.now()});
assert.deepEqual(await get('/healthz'),{ok:true});
const forged=await new Promise((resolve,reject)=>http.get(base+'/api/status',{headers:{Host:'rebinding.invalid:13080'}},
  r=>{r.resume();resolve(r.statusCode);}).on('error',reject));
assert.equal(forged,421);
for(const origin of ['http://rebinding.invalid:13080',base.replace('http:','https:'),'null']) {
  const rejected=await fetch(base+'/api/capture',{method:'POST',headers:{origin,'content-type':'application/json'},
    body:'{"paused":true}'});
  assert.equal(rejected.status,403,origin);
}
assert.equal((await get('/api/status')).paused,false);
const homepage=await fetch(base);
assert.equal(homepage.headers.get('x-frame-options'),'DENY');
assert.equal(homepage.headers.get('referrer-policy'),'no-referrer');
for (const path of ['/','/app.js','/theme.js','/timeline.js','/power.js','/style.css']) {
  assert.equal((await fetch(base+path)).status,200);
}
const legacy = await get('/api/channels?'+bounds);
for (const [direction,id,power] of [['downstream',9,-7],['upstream',8,40]]) {
  const key = legacy[direction].find(k=>JSON.parse(k)[1]===id);
  assert.ok(key,'Historically present but disconnected channel missing');
  const query=new URLSearchParams(bounds);
  for (const [p,v] of Object.entries({direction,key,metric:'power'})) query.set(p,v);
  const {history,available} = await get('/api/history?'+query);
  assert.ok(available.includes(key));
  assert.equal(history.reduce((n,p)=>n+p.count,0),2);
  assert.equal(Math.min(...history.map(p=>p.min)),power);
  const overview=await get('/api/power?'+bounds+'&direction='+direction);
  assert.equal(overview.series.length>=2,true);
  assert.ok(overview.series.every(row=>row.points.length<=600));
  assert.equal(overview.series.find(row=>row.key===key).points.at(-1).power,power+1);
}
assert.ok((await get('/api/events?'+bounds)).events.some(r=>r.message==='Legacy event [redacted]'));
const linked=await get('/api/correlation?event=logged-channel');
const match=linked.directions.upstream.rows.find(r=>r.reported);
assert.equal(match.id,8);
assert.equal(match.frequencyHz,37000000);
assert.equal(match.power,1);
assert.equal(linked.directions.downstream.rows.find(r=>r.id===9).before,-7);
const ambiguous=await get('/api/correlation?event=ambiguous-channel');
assert.equal(ambiguous.reference.explicitId,false);
assert.ok(ambiguous.directions.upstream.rows.every(r=>!r.reported));
const info=await get('/api/modem');
assert.equal(info.docsisVersion,'3.1');
assert.equal(info.primary.upstream.frequencyHz,24000000);
assert.equal(info.serviceFlows[0].maxRate,100000000);
assert.doesNotMatch(JSON.stringify(info),/serialNumber|should-not-appear/);
const csv = await fetch(base+'/api/rf.csv?'+bounds);
assert.equal(csv.status,200);
assert.match(await csv.text(),/"OFDM","400000000"/);
assert.equal((await get('/api/status')).settings.interval,60);
const cadence = async (interval,wait,min,max) => {
  assert.equal((await select(interval)).interval,interval);
  const before = await stats();
  await sleep(wait);
  const after = await stats();
  for (const source of ['downstream','upstream']) {
    const starts=after.stats[source].slice(before.stats[source].length);
    const steps=starts.slice(1).map((t,i)=>t-starts[i]).sort((a,b)=>a-b);
    assert.ok(steps.length>=3,source+' insufficient samples');
    const median=steps[Math.floor(steps.length/2)];
    assert.ok(median>=min && median<=max,source+' median '+median+' ms');
  }
  assert.ok(after.stats.eventlog.length-before.stats.eventlog.length<=1);
  assert.equal(after.overlap,0);
};
await cadence(1,4500,870,1130);
await cadence(0.5,2600,390,610);
for(const [direction,frames] of await Promise.all(['downstream','upstream'].map(async direction=>[direction,await readLive(direction,4)]))) {
  assert.ok(frames.every(frame=>frame.direction===direction && frame.rows.length===2 && frame.serverTime>=frame.time));
  const times=frames.map(frame=>frame.time);
  assert.ok(times.every((time,i)=>!i || time-times[i-1]>=390 && time-times[i-1]<=610),times.join(','));
  const query=new URLSearchParams({direction,from:times[0],to:times.at(-1)});
  const overview=await get('/api/power?'+query);
  assert.equal(overview.bucketMs,1);
  const key=frames[0].rows[0].key;
  const points=overview.series.find(row=>row.key===key).points;
  assert.deepEqual(points,times.map((time,i)=>({time,power:frames[i].rows.find(row=>row.key===key).power})));
  query.set('key',key);
  query.set('metric','power');
  const detail=await get('/api/history?'+query);
  assert.equal(detail.bucketMs,1);
  assert.deepEqual(detail.history.map(p=>p.time),times);
}
await (await fetch(mock+'/slow')).json();
await sleep(300);
const before=await stats();
await sleep(2850);
const after=await stats();
assert.equal(after.overlap,0);
const counts = source => after.stats[source].length-before.stats[source].length;
assert.ok(counts('downstream')>=5 && counts('upstream')>=2 && counts('upstream')<counts('downstream'));
const rejected = await fetch(base+'/api/settings',{method:'POST',headers:{origin:base,'content-type':'application/json'},
  body:JSON.stringify({interval:0.75,retention:90})});
assert.equal(rejected.status,400);
assert.equal((await select(2.5)).interval,2.5);
assert.equal((await select(0.5)).interval,0.5);
const current=await get('/api/status');
assert.equal(current.settings.interval,0.5);
assert.equal(current.cadenceMs.eventlog,30000);
assert.deepEqual(current.current.downstream.map(r=>r.type).sort(),['OFDM','SC-QAM']);
assert.deepEqual(current.current.upstream.map(r=>r.type).sort(),['OFDMA','SC-QAM']);
const recent=new URLSearchParams({from:Date.now()-6000,to:Date.now()});
for(const direction of ['downstream','upstream']) {
  const overview=await get('/api/power?'+recent+'&direction='+direction);
  assert.deepEqual(overview.series.map(row=>row.key).sort(),current.current[direction].map(row=>row.key).sort());
  assert.ok(overview.series.every(row=>row.points.length>=3 && row.points.every(p=>Number.isFinite(p.power))));
}
console.log('Compose health, legacy history/CSV, both power graphs, exact persisted live samples, both capture rates and slow-endpoint isolation passed.');
const pause=async paused=>get('/api/capture',{method:'POST',headers:{origin:base,'content-type':'application/json'},
  body:JSON.stringify({paused})});
assert.deepEqual(await pause(true),{paused:true});
const lastStatus=await stats();
await sleep(1400);
assert.deepEqual((await stats()).stats,lastStatus.stats,'Paused capture still sent requests');
assert.equal((await get('/api/status')).paused,true);
assert.ok((await get('/api/correlation?event=logged-channel')).directions.upstream.rows.some(r=>r.reported));
