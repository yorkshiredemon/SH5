const detailTime = new Intl.DateTimeFormat('en-GB',{
  timeZone:'Europe/London',day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',
  fractionalSecondDigits:3,timeZoneName:'short'
});
const axisTime = [
  {hour:'2-digit',minute:'2-digit',second:'2-digit',fractionalSecondDigits:3},
  {hour:'2-digit',minute:'2-digit',second:'2-digit'},
  {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'},
  {day:'numeric',month:'short',year:'2-digit'}
].map(options=>new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',...options}));
const displayNumber = new Intl.NumberFormat('en-GB',{maximumFractionDigits:2});
const axisNumber = new Intl.NumberFormat('en-GB',{notation:'compact',maximumFractionDigits:2});
const minSpan = 1000;
const maxSpan = 366*86400000;
const $ = id => document.getElementById(id);
const clamp = (value,lo,hi) => Math.min(hi,Math.max(lo,value));

export function timeline(changeView) {
  const canvas = $('plot'), ctx = canvas.getContext('2d');
  let state, view, drag, focusTime, geometry, points = [];
  function windowChange(from,to) {
    const width = clamp(Math.round(to-from),minSpan,maxSpan);
    from = clamp(Math.round(from),0,Date.now()-width);
    changeView({from,to:from+width});
  }
  function scale(factor) {
    if (!view) return;
    const oldSpan = view.to-view.from;
    const span = clamp(Math.round(oldSpan*factor),minSpan,maxSpan);
    const anchor = focusTime ?? Math.round((view.from+view.to)/2);
    const from = Math.round(anchor-(anchor-view.from)*span/oldSpan);
    windowChange(from,from+span);
  }
  function pan(fraction) {
    if (!view) return;
    const shift = (view.to-view.from)*fraction;
    windowChange(view.from+shift,view.to+shift);
  }
  $('plot-in').onclick = () => scale(.5);
  $('plot-out').onclick = () => scale(2);
  $('plot-prev').onclick = () => pan(-.5);
  $('plot-next').onclick = () => pan(.5);
  $('plot-reset').onclick = () => changeView(null);

  function nearest(time) {
    let lo=0, hi=points.length;
    while (lo<hi) {
      const mid = (lo+hi)>>1;
      if (points[mid].time<time) lo=mid+1;
      else hi=mid;
    }
    if (lo===points.length || lo && time-points[lo-1].time<=points[lo].time-time) return lo-1;
    return lo;
  }
  function inspect(timestamp) {
    focusTime = timestamp;
    draw();
  }
  function plotX(event) {
    return clamp(event.clientX-canvas.getBoundingClientRect().left,geometry.left,geometry.right);
  }
  canvas.addEventListener('pointerdown',event => {
    if (!geometry || !points.length || !event.isPrimary || event.button!==0) return;
    const x = plotX(event);
    drag = {id:event.pointerId,start:x,end:x};
    canvas.setPointerCapture(event.pointerId);
    inspect(points[nearest(geometry.time(x))]?.time);
  });
  canvas.addEventListener('pointermove',event => {
    if (!geometry || !points.length) return;
    const x = plotX(event);
    if (drag?.id===event.pointerId) drag.end = x;
    else if (event.pointerType==='touch') return;
    inspect(points[nearest(geometry.time(x))]?.time);
  });
  canvas.addEventListener('pointerup',event => {
    if (drag?.id!==event.pointerId) return;
    const start = drag.start, end = plotX(event);
    drag = null;
    if (Math.abs(end-start)>=12 && Math.abs(geometry.time(end)-geometry.time(start))>=minSpan) {
      const a = geometry.time(Math.min(start,end)), b = geometry.time(Math.max(start,end));
      windowChange(a,b);
    } else draw();
  });
  canvas.addEventListener('lostpointercapture',() => { if (drag) { drag=null; draw(); } });
  canvas.addEventListener('keydown',event => {
    if (!points.length) return;
    if (event.key==='Escape') inspect(null);
    else if (['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) {
      let index = focusTime == null ? (event.key==='ArrowLeft' ? points.length-1 : 0) :
        nearest(focusTime)+(event.key==='ArrowLeft' ? -1 : 1);
      if (event.key==='Home') index = 0;
      if (event.key==='End') index = points.length-1;
      inspect(points[clamp(index,0,points.length-1)].time);
    } else return;
    event.preventDefault();
  });
  function draw() {
    const w = canvas.clientWidth, h = canvas.clientHeight, dpr = devicePixelRatio || 1;
    const cw = Math.round(w*dpr), ch = Math.round(h*dpr);
    if (canvas.width!==cw) canvas.width = cw;
    if (canvas.height!==ch) canvas.height = ch;
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,w,h);
    geometry = null;
    const detail = $('plot-detail');
    let description = '';
    if (!points.length || w<90) {
      if (detail.textContent) detail.textContent = '';
      return;
    }
    const {metric,isCounter,bucketMs,interval,rows} = state;
    const span = view.to-view.from;
    const style = getComputedStyle(document.documentElement);
    const colour = name => style.getPropertyValue('--'+name).trim();
    const left=54, right=w-12, top=13, bottom=h-28;
    const high = Math.max(...points.map(p=>isCounter?p.sum:p.max));
    const low = isCounter ? 0 : Math.min(...points.map(p=>p.min));
    const lo = metric==='lock' ? 0 : low===high && !isCounter ? low-1 : low;
    const hi = metric==='lock' ? 1 : high===low ? high+1 : high;
    const x = time => left+(time-view.from)/span*(right-left);
    const y = value => bottom-(value-lo)/(hi-lo)*(bottom-top);
    geometry = {left,right,time:px=>view.from+(px-left)/(right-left)*span};
    const line = (ax,ay,bx,by) => {ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();};
    ctx.font = '11px system-ui';
    ctx.strokeStyle = colour('border');
    ctx.fillStyle = colour('muted');
    const ticks = metric==='lock' ? 1 : 4;
    for (let i=0;i<=ticks;i++) {
      const value = lo+(hi-lo)*i/ticks;
      line(left,y(value),right,y(value));
      ctx.fillText(metric==='lock' ? (i ? 'Locked' : 'Unlocked') : axisNumber.format(value),1,y(value)+4);
    }
    const steps = w<480 ? 2 : w<780 ? 3 : 5;
    const formatter = axisTime[span<=60000 ? 0 : span<=3600000 ? 1 : span<=7*86400000 ? 2 : 3];
    for (let i=0;i<steps;i++) {
      const t = view.from+span*i/(steps-1);
      const label = formatter.format(t);
      ctx.fillText(label,clamp(x(t)-ctx.measureText(label).width/2,0,w-ctx.measureText(label).width),h-6);
    }
    let prior;
    const gap = Math.max(interval*3000,bucketMs*3,2000);
    const ink = colour('line'), envelope = colour('envelope');
    let missing=false;
    const hold=(ax,bx,py)=>{
      ctx.globalAlpha=.42;
      line(ax,py,bx,py);
      ctx.globalAlpha=1;
    };
    for (const point of rows) {
      if (!point.count) {missing=true;continue;}
      const value = isCounter ? point.sum : point.sum/point.count;
      const px=x(point.time), py=y(value);
      if (!isCounter && point.min!==point.max) {
        ctx.strokeStyle=envelope;
        line(px,y(point.min),px,y(point.max));
      }
      ctx.strokeStyle=ink;
      if (isCounter && value>0) line(px,bottom,px,py);
      if (!isCounter && prior) {
        if (missing || point.time-prior.last>gap) hold(prior.x,px,prior.y);
        else line(prior.x,prior.y,px,prior.y);
        line(px,prior.y,px,py);
      }
      ctx.fillStyle=ink;
      ctx.fillRect(px-1.5,py-1.5,3,3);
      prior={x:px,y:py,last:point.last};
      missing=false;
    }
    if (!isCounter && prior && prior.x<right) {
      const fresh=missing ? prior.x : Math.min(right,x(prior.last+Math.max(bucketMs,interval*1000)));
      ctx.strokeStyle=ink;
      line(prior.x,prior.y,fresh,prior.y);
      if (fresh<right) hold(fresh,right,prior.y);
    }
    if (Number.isFinite(state.marker) && state.marker>=view.from && state.marker<=view.to) {
      const px=x(state.marker);
      ctx.strokeStyle=colour('event-line');ctx.fillStyle=colour('event-line');ctx.setLineDash([5,4]);
      line(px,top,px,bottom);ctx.setLineDash([]);
      const label=state.markerLabel ?? 'Event';
      ctx.fillText(label,Math.min(right-ctx.measureText(label).width,px+5),top+11);
    }
    if (drag) {
      ctx.fillStyle=colour('select');
      ctx.fillRect(Math.min(drag.start,drag.end),top,Math.abs(drag.end-drag.start),bottom-top);
    }
    if (focusTime != null) {
      const p = points[nearest(focusTime)];
      const px = x(p.time);
      ctx.setLineDash([4,3]);
      ctx.strokeStyle=ink;
      line(px,top,px,bottom);
      ctx.setLineDash([]);
      const start=detailTime.format(p.time);
      const period=p.time===p.last ? start : start+' → '+detailTime.format(p.last);
      const n = displayNumber.format.bind(displayNumber);
      const values = isCounter ? 'Δ '+n(p.sum)+' · '+p.resets+' decreases' :
        metric==='lock' && p.min===p.max ? (p.min ? 'Locked' : 'Unlocked') :
          'Mean '+n(p.sum/p.count)+' · min '+n(p.min)+' · max '+n(p.max);
      description=period+' · '+values+' · '+p.count+(p.count===1 ? ' value' : ' values');
    }
    if (detail.textContent!==description) detail.textContent=description;
  }
  new ResizeObserver(draw).observe(canvas);
  window.addEventListener('hub5-themechange',draw);
  return {
    render(nextView,nextState,zoomed=false) {
      if (state?.identity!==nextState?.identity) focusTime = null;
      view=nextView;
      state=nextState;
      points=state?.rows?.filter(p=>p.count) ?? [];
      if (focusTime != null && (focusTime<view.from || focusTime>view.to)) focusTime = null;
      const span = view ? view.to-view.from : 0;
      $('plot-in').disabled=!points.length || span<=minSpan;
      $('plot-out').disabled=!view || span>=maxSpan;
      $('plot-prev').disabled=!view || view.from===0;
      $('plot-next').disabled=!view || view.to>=Date.now()-1000;
      $('plot-reset').disabled=!zoomed;
      draw();
    }
  };
}
