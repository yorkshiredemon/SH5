(() => {
  const root = document.documentElement;
  const scheme = matchMedia('(prefers-color-scheme: dark)');
  const key = 'hub5-theme';
  let preference = 'system';
  try {
    const saved = localStorage.getItem(key);
    if (['system','light','dark'].includes(saved)) preference = saved;
  } catch {}
  function apply() {
    root.dataset.theme = preference === 'system' ? (scheme.matches ? 'dark' : 'light') : preference;
    window.dispatchEvent(new Event('hub5-themechange'));
  }
  apply();
  scheme.addEventListener('change',() => { if (preference === 'system') apply(); });
  document.addEventListener('DOMContentLoaded',() => {
    const select = document.getElementById('theme');
    select.value = preference;
    select.addEventListener('change',() => {
      preference = select.value;
      try { localStorage.setItem(key,preference); } catch {}
      apply();
    });
  });
})();
