import assert from 'node:assert/strict';
import {setTimeout as wait} from 'node:timers/promises';
const base=process.env.MONITOR_TEST_URL;
const mock=process.env.MOCK_TEST_URL;
const status=async()=>fetch(base+'/api/status').then(r=>r.json());
const stats=async()=>(await fetch(mock+'/stats').then(r=>r.json())).stats;
const before=await stats();
let saved;
for(let attempt=0;attempt<20;attempt++){
  saved=await status().catch(()=>null);
  if(saved)break;
  await wait(150);
}
assert.equal(saved?.paused,true);
assert.equal(saved.settings.interval,.5);
await wait(1100);
assert.deepEqual(await stats(),before,'Paused restart made modem requests');
const res=await fetch(base+'/api/capture',{method:'POST',headers:{origin:base,'content-type':'application/json'},body:'{"paused":false}'});
assert.equal(res.status,200);
assert.equal((await res.json()).paused,false);
await wait(1250);
const after=await stats();
assert.ok(after.downstream.length>before.downstream.length && after.upstream.length>before.upstream.length);
console.log('Polling pause survives restart, keeps saved history accessible and resumes both RF streams.');
