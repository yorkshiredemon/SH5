# Hub 5 DOCSIS Monitor

A read-only collector and LAN dashboard for the Virgin Media Hub 5. It reads downstream, upstream, events and modem inventory over the Hub's management interface. It uses Node.js 24 and SQLite with no npm dependencies.

## Start on the Debian Docker VM

From the extracted `hub5-docsis-monitor` directory on `192.168.1.67`:

```bash
docker compose up -d --build
docker compose logs -f monitor
```

Open [http://192.168.1.67:3000](http://192.168.1.67:3000). The first poll starts when the service starts. The dashboard refreshes every 30 seconds and offers a manual refresh. Use the dashboard's source cards to verify all three endpoints.

Defaults are a 60-second poll interval and 90 days of retention. Settings are stored in SQLite and take effect without restarting. Lowering retention removes older records. Docker Compose uses a named volume for the SQLite database. Keep this volume when replacing the container.

For an existing installation, back up SQLite using its online backup API (or stop the monitor for a consistent copy), then update the source in the original Compose directory. Use the same [Compose project name](https://docs.docker.com/compose/how-tos/project-name/) and settings overrides. Run `docker compose up -d --build --wait monitor` and confirm that the monitor still mounts the original `history` volume at `/app/data`. Keep the volume when rolling back as well. No schema migration is needed, and the filename remains `history.sqlite`. If rolling back to the original release, first set a 30–900 second whole-number interval so its settings form can edit it.

Use a `.env` file to override `BIND_IP`, `WEB_PORT`, `HUB_URL` or `HUB_TLS_INSECURE`. The shipped Compose file binds to the VM's LAN IP and allows the Hub's self-signed certificate for collector requests only. Set `HUB_TLS_INSECURE=0` when the Hub certificate is trusted by the container. The dashboard has no login and uses HTTP. Keep the port on a trusted LAN; any device that can connect can read data and change capture settings. Do not port-forward it. For an authenticated HTTPS reverse proxy, bind the backend where only the proxy can reach it, preserve Host, and set DASHBOARD_ORIGINS to the comma-separated exact browser origins (including scheme and non-default ports).

If an endpoint fails, first verify reachability from the VM. These commands print HTTP status only:

```bash
for endpoint in downstream upstream eventlog; do
  curl -ksS --max-time 10 -o /dev/null -w "%{http_code} $endpoint\n" \
    "https://192.168.100.1/rest/v1/cablemodem/$endpoint"
done
```

If the VM gets HTTP 200 and the application reports timeouts, check Docker's route to `192.168.100.1` and any overlap between Docker networks and your LAN/modem subnet. The `/healthz` endpoint checks the application and database. `/api/status` reports collection health per source.

## Reading the dashboard

- Choose **Light**, **Dark** or **System** in the header. The browser remembers your choice. System follows changes to the device appearance.
- Open **Downstream** or **Upstream** for the multi-channel chart. Drag across time, double-click an empty part of the plot or use the zoom controls to inspect a smaller window. Click a trace to open that channel around the selected reading. Short ranges show every capture; longer ranges show the newest reading per interval. Faded segments hold the last measured level. **By frequency** labels reported channel centres in MHz. Any connecting line is a visual guide between discrete readings.
- The live badge shows when readings are arriving, delayed or reconnecting, with a millisecond timestamp for the last sample. The signal views and short rolling Channel History views receive new RF readings via Server-Sent Events immediately after SQLite commits. Zoomed and custom history stay fixed for inspection. Capture still depends on the Hub's response time. If proxying the dashboard, keep response buffering disabled for `/api/live`.
- Select a channel in History or click its ID in the latest measurements. The picker includes all current channels and any historical channels in the selected range. Select a metric, drag across the timeline or use its zoom and pan buttons, and inspect points by hovering, tapping or pressing the arrow keys on the focused chart. A short range shows individual captures with millisecond timestamps. Reset view returns to the main time range, which also controls event views and CSV exports.
- **Diagnostics** shows DOCSIS state, uptime, registration, primary frequencies, configured service-flow rates, and reported bandwidth, symbol rate, FFT and active-subcarrier fields. The monitor follows the Hub firmware conversion for its known downstream OFDM format: stored raw power and MER values in tenths are converted on read, including older samples. Original rows and channel keys are unchanged. New rows keep only the RF metadata used by the monitor, rather than the entire modem payload. The first-active field is shown raw and is not used as a centre frequency.
- For power and MER/SNR, long-range charts show the mean and min/max per interval. Counter charts sum observed deltas. The first sample, missing values, the first sample after a failed poll, and decreases contribute no delta. A decrease can result from a reset or wrap. The Hub may reset counters between sample times, which the collector cannot always detect.
- The event log deduplicates on time, priority and message. Recognised identifiers are removed from new event messages before storage, and are masked in dashboard and CSV reads of older records. Existing original messages were not rewritten; old SQLite files, WAL files and backups may still contain identifiers. Counts in the daily summary are counts of log entries, including when a single ranging episode produces multiple entries.
- Ranging incidents group related event-log entries and sampled T3/T4 counter increases with gaps of up to five minutes. The RF section shows nearby sample times, measured channel changes and available counter deltas. The sampling cadence and the Hub's clock affect time alignment. Temporal correlation alone cannot establish the cause. Click an event timestamp or **Investigate on charts** to open a four-minute window with an event marker. The panel distinguishes a unique logged channel ID or frequency from nearby changes. A generic “upstream channel N” is not assumed to be a published channel ID. Frequency comparison shows the nearest before-and-after snapshots.
- The Downstream and Upstream tabs share a time chart range. Channel History and Events have their own range controls, which also apply to their CSV exports. Events shows up to 250 log entries and 50 incident groups per range. CSV exports include the full range. Dashboard timestamps are shown in UK time. Custom inputs use the browser time zone. CSV and daily grouping use UTC.

The tested firmware's LAN endpoints and dashboard did not expose upstream pre-EQ coefficients, per-subcarrier RxMER or full-band spectrum samples. Those plots need a supported source for [DOCSIS 3.1 PNM measurements](https://account.cablelabs.com/server/alfresco/c021877d-cce7-434a-b3ac-9cc466d6c601). The reported channel-level values cannot reconstruct them.

## Fast capture

In Settings, use the slider, presets, or exact interval field and then click **Save settings**. Intervals range from **500 ms** to **900 seconds** in half-second steps. Each RF endpoint has an independent timer. A slow response skips missed polling slots and never triggers overlapping requests to the same endpoint. The network log stays at a minimum interval of 30 seconds. The selected RF interval is a target, so actual spacing depends on the Hub, network and host load. Modem inventory is refreshed no faster than once a minute.

Switch **Polling enabled** off in Settings to stop all modem requests while keeping the charts and history available. The pause is saved as capture.json beside SQLite on the existing data volume. Resume starts fresh requests and resets the counter-delta baseline.

At 500 ms, 40 successfully captured channels generate about 6.9 million sample rows per day; at 1 second they generate about 3.5 million. Check disk growth and adjust retention for sustained fast capture. Lowering retention deletes older data. The 500 ms setting is stored as 0.5 seconds in the original interval column using [SQLite's numeric affinity](https://www.sqlite.org/datatype3.html#comparison_example).

## Repeat the Docker smoke test

Run `./test/run-compose-smoke.sh` with Docker Compose and Node.js 24 or later. It uses loopback ports 13080 and 13081 (override with `WEB_PORT` and `MOCK_WEB_PORT` if needed), a separate project and a disposable database seeded with legacy rows. It tests health, history and CSV reads, both fast intervals, slow-endpoint isolation, SQLite schema and row preservation, and persistence across restart. It also verifies event-to-channel evidence, OFDM scaling, modem inventory, and that a saved pause survives restart.

## Privacy and access

The app has no analytics, accounts, cloud log sharing or packet capture. The only app-initiated network requests go to the configured Hub. The browser stores the theme choice locally. Event text is supplied by the Hub; redaction covers recognised MAC, IP and email formats and common labelled identifier fields, but is not a guarantee of anonymisation of arbitrary text. RF measurements and event timing remain local records about the line. The build context contains only the server modules and required web assets, and releases do not include your SQLite files, logs, environment files or credentials.

The server accepts only the configured dashboard address and explicit proxy origins (plus loopback). Settings writes must originate from the same configured browser origin. This is a browser request safeguard, not user authentication. See [OWASP's origin validation guidance](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html). Keep local database backups private.
