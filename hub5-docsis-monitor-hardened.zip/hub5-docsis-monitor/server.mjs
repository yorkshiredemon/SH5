import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {once} from 'node:events';
import {createHash} from 'node:crypto';
import {setImmediate as yieldToLoop} from 'node:timers/promises';
import {channels,counters,displayMetric,events,frequencyHz,getHub,metrics,redact,rfMetadata,sources} from './modem.mjs';

const hub = new URL(process.env.HUB_URL ?? 'https://192.168.100.1');
if (!['http:', 'https:'].includes(hub.protocol) || hub.username || hub.password) throw Error('Invalid HUB_URL');
const tls = process.env.HUB_TLS_INSECURE !== '1';
const day = 86400000;
process.umask(0o077);
const dataDir = process.env.DATA_DIR ?? 'data';
mkdirSync(dataDir, {recursive:true, mode:0o700});
const controlFile=dataDir+'/capture.json';
let paused=false;
try {
  const saved=JSON.parse(readFileSync(controlFile,'utf8'));
  if (typeof saved.paused!=='boolean') throw Error('Invalid capture control');
  paused=saved.paused;
} catch(error) {
  // Fail closed if a saved control is unreadable.
  if (error.code!=='ENOENT') {paused=true;console.warn('Capture is paused:',error.message);}
}
const db = new DatabaseSync(dataDir+'/history.sqlite');
db.exec(`
  PRAGMA journal_mode=WAL;
  CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY, interval INTEGER, retention INTEGER);
  INSERT OR IGNORE INTO settings VALUES (1, 60, 90);
  CREATE TABLE IF NOT EXISTS source_status (source TEXT PRIMARY KEY, attempted INTEGER, good INTEGER, error TEXT);
  CREATE TABLE IF NOT EXISTS samples (direction TEXT, time INTEGER, key TEXT, data TEXT, PRIMARY KEY(direction,time,key));
  CREATE INDEX IF NOT EXISTS channel_history ON samples(direction,key,time);
  CREATE TABLE IF NOT EXISTS ranging (time INTEGER PRIMARY KEY, counts TEXT);
  CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, time INTEGER, priority TEXT, message TEXT);
  CREATE INDEX IF NOT EXISTS event_time ON events(time);
`);
const settings = () => db.prepare('SELECT interval, retention FROM settings WHERE id=1').get();
const putSample = db.prepare('INSERT INTO samples VALUES (?,?,?,?)');
const putEvent = db.prepare('INSERT OR IGNORE INTO events VALUES (?,?,?,?)');
const knownEvent = db.prepare('SELECT 1 FROM events WHERE id=?');
const eventId = row => createHash('sha256').update(JSON.stringify(row)).digest('hex');
const markSource = db.prepare(`INSERT INTO source_status VALUES (?,?,?,?)
  ON CONFLICT(source) DO UPDATE SET attempted=excluded.attempted,
  good=coalesce(excluded.good,source_status.good),error=excluded.error`);
const rowsAt = db.prepare('SELECT data FROM samples WHERE direction=? AND time=? ORDER BY key');
const readAt = (direction,time) => rowsAt.all(direction,time).map(row => JSON.parse(row.data));
const rfDirections = ['downstream','upstream'];
const restartBaseline=new Set(rfDirections);
const publicRow = sample => {
  const {raw,...row}=sample;
  return {...row,...rfMetadata(sample),power:displayMetric(sample,'power'),mer:displayMetric(sample,'mer'),fields:Object.keys(raw ?? {})};
};
const publicRows = rows => rows.map(publicRow);
const liveClients = new Map(rfDirections.map(direction=>[direction,new Set()]));
const latestFrames = new Map();
function sendLive(res,chunk) {
  // Slow/disconnected browsers must never hold up capture or queue frames.
  if (res.destroyed || res.writableEnded || !res.write(chunk)) res.destroy();
}
function publishRF(direction,event,data,replay=true) {
  const frame = 'event: '+event+'\ndata: '+JSON.stringify({direction,...data})+'\n\n';
  if (replay) latestFrames.set(direction,frame);
  for (const res of liveClients.get(direction)) sendLive(res,frame);
}
function prune(now) {
  const cutoff = now-settings().retention*day;
  db.prepare('DELETE FROM samples WHERE time < ?').run(cutoff);
  db.prepare('DELETE FROM events WHERE time < ?').run(cutoff);
  db.prepare('DELETE FROM ranging WHERE time < ?').run(cutoff);
}
function store(source, time, rows) {
  db.exec('BEGIN IMMEDIATE');
  try {
    if (source === 'eventlog') {
      const cutoff = time-settings().retention*day;
      for (const row of rows) {
        if (row.time < cutoff) continue;
        // Preserve deduplication against the original database without
        // writing any raw messages or their fingerprints for new events.
        const safe={...row,message:redact(row.message)};
        const id=eventId(safe);
        if (knownEvent.get(id) || (safe.message!==row.message && knownEvent.get(eventId(row)))) continue;
        putEvent.run(id,safe.time,safe.priority,safe.message);
      }
    } else {
      const previous = db.prepare('SELECT good, error FROM source_status WHERE source=?').get(source);
      const prior = new Map(previous?.error || restartBaseline.has(source) ? [] : readAt(source,previous?.good ?? 0).map(row => [row.key,row]));
      const ranging = [];
      for (const row of rows) {
        const before = prior.get(row.key);
        row.delta = {};
        row.reset = [];
        for (const name of counters) {
          row.delta[name] = null;
          if (row[name] == null || before?.[name] == null) continue;
          if (row[name] < before[name]) row.reset.push(name);
          else row.delta[name] = row[name]-before[name];
        }
        row.lockChanged = before?.lock != null && row.lock != null && row.lock !== before.lock;
        putSample.run(source,time,row.key,JSON.stringify(row));
        if (source === 'upstream' && (row.delta.t3 > 0 || row.delta.t4 > 0)) {
          ranging.push({key:row.key,id:row.id ?? row.frequency,type:row.type,frequencyHz:frequencyHz(row.frequency),t3:row.delta.t3,t4:row.delta.t4});
        }
      }
      if (ranging.length) db.prepare('INSERT INTO ranging VALUES (?,?)').run(time,JSON.stringify(ranging));
    }
    markSource.run(source,time,time,null);
    db.exec('COMMIT');
    restartBaseline.delete(source);
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
const captureSources=[...sources,'modem'];
const collectors = Object.fromEntries(captureSources.map(source => [source,{running:false,lastError:null}]));
const cadence = (source, interval) =>
  (source === 'modem' ? Math.max(interval,60) : source === 'eventlog' ? Math.max(interval,30) : interval)*1000;
const inventorySources=['state_','registration','serviceflows','downstream/primary_','upstream/primary_'];
let inventory={};
async function inventoryPoll(signal) {
  const result=await Promise.allSettled(inventorySources.map(source=>getHub(hub,source,tls,signal)));
  if (signal.aborted) return;
  const [state,registration,flows,ds,us]=result.map(r=>r.status==='fulfilled'?r.value:null);
  const modem=state?.cablemodem, reg=registration?.registration;
  const finite = value=>Number.isFinite(value)?value:null;
  const text=value=>typeof value==='string'?value:null;
  const flag=value=>typeof value==='boolean'?value:null;
  const primary=data=>data?.channel ? {id:finite(data.channel.channelId),frequencyHz:frequencyHz(data.channel.frequency),
    modulation:text(data.channel.modulation)}:null;
  inventory={captured:Date.now(),docsisVersion:text(modem?.docsisVersion),state:text(modem?.status),uptime:finite(modem?.upTime),
    registered:flag(reg?.registrationComplete),downstreamLocked:flag(reg?.downstreamLocked),
    primary:{downstream:primary(ds),upstream:primary(us)},
    serviceFlows:(Array.isArray(flows?.serviceFlows)?flows.serviceFlows:[]).map(row=>row?.serviceFlow)
      .filter(f=>rfDirections.includes(f?.direction)).map(f=>({direction:f.direction,maxRate:finite(f.maxTrafficRate),
        minRate:finite(f.minReservedRate),schedule:text(f.scheduleType)})),
    unavailable:inventorySources.filter((_,i)=>result[i].status==='rejected')};
}
function changePause(next) {
  if (next===paused) return;
  writeFileSync(controlFile+'.tmp',JSON.stringify({paused:next})+'\n',{mode:0o600});
  renameSync(controlFile+'.tmp',controlFile);
  paused=next;
  for (const direction of rfDirections) {
    if (paused) restartBaseline.add(direction);
    if (!paused) latestFrames.delete(direction);
    publishRF(direction,'capture-state',{paused,serverTime:Date.now()},false);
  }
  for (const source of captureSources) {
    const state=collectors[source];
    clearTimeout(state.timer);
    if (paused) state.request?.abort();
    else if (!state.running) poll(source);
    else state.restart=true;
  }
}
function schedule(source) {
  const state = collectors[source];
  clearTimeout(state.timer);
  if (paused || state.running) return;
  const interval = cadence(source,settings().interval);
  const elapsed = performance.now()-state.started;
  // Anchor to the previous start and skip missed slots. Never stack requests.
  const delay = elapsed < interval ? interval-elapsed : interval-elapsed%interval;
  state.timer = setTimeout(() => poll(source),delay);
}
async function poll(source) {
  const state = collectors[source];
  if (paused || state.running) return;
  state.running = true;
  const signal=(state.request=new AbortController()).signal;
  state.started = performance.now();
  const now = Math.max(Date.now(),(state.timestamp ?? 0)+1);
  state.timestamp = now;
  try {
    if (source==='modem') return await inventoryPoll(signal);
    const payload = await getHub(hub,source,tls,signal);
    if (signal.aborted) return;
    const rows = source === 'eventlog' ? events(payload) : channels(payload,source);
    store(source,now,rows);
    state.lastError = null;
    if (source !== 'eventlog') publishRF(source,'sample',{time:now,serverTime:Date.now(),
      cadenceMs:cadence(source,settings().interval),rows:publicRows(rows)});
  } catch (error) {
    if (signal.aborted) return;
    if (state.lastError !== error.message) console.warn(source,error.message);
    state.lastError = error.message;
    if (source==='modem') return;
    try { markSource.run(source,now,null,error.message); }
    catch (dbError) { console.error(dbError); }
    if (source !== 'eventlog') publishRF(source,'capture-error',{time:now,serverTime:Date.now(),error:error.message});
  } finally {
    state.running = false;
    state.request=null;
    const restart=state.restart;
    state.restart=false;
    if (restart && !paused) poll(source);
    else schedule(source);
  }
}
const lastAttempt = db.prepare('SELECT attempted FROM source_status WHERE source=?');
const samplesQuery = db.prepare('SELECT time,data FROM samples WHERE direction=? AND key=? AND time BETWEEN ? AND ? ORDER BY time LIMIT 2048');
const powerSql=field=>`(CASE WHEN json_extract(${field},'$.raw.channelType')='ofdm'
  AND json_type(${field},'$.raw.fftType')='text'
  AND json_type(${field},'$.raw.numberOfActiveSubCarriers') IN ('integer','real')
  THEN json_extract(${field},'$.power')/10.0 ELSE json_extract(${field},'$.power') END)`;
const rawPowerSeries = db.prepare(`SELECT time,${powerSql('data')} AS power
  FROM samples INDEXED BY channel_history WHERE direction=? AND key=? AND time BETWEEN ? AND ? ORDER BY time`);
const rawSpan = 300000;
// Jump between distinct keys via the existing index instead of walking every
// sample just to populate the channel picker. Check the selected range per key.
const historyKeys = db.prepare(`
  WITH RECURSIVE keys(key) AS (
    SELECT min(key) FROM samples WHERE direction=?1
    UNION ALL
    SELECT (SELECT min(s.key) FROM samples s WHERE s.direction=?1 AND s.key>keys.key)
    FROM keys WHERE key IS NOT NULL
  ) SELECT key FROM keys WHERE EXISTS (
    SELECT 1 FROM samples s WHERE s.direction=?1 AND s.key=keys.key AND s.time BETWEEN ?2 AND ?3
  ) ORDER BY key
`);
function availableKeys(direction, [from,to]) {
  return historyKeys.all({'1':direction,'2':from,'3':to}).map(row => row.key);
}
// One indexed seek per channel per interval keeps wide views bounded even
// when the database contains months of sub-second captures.
const powerSeries = db.prepare(`
  WITH RECURSIVE buckets(start) AS (
    VALUES (?3)
    UNION ALL SELECT start+?5 FROM buckets WHERE start+?5<=?4
  )
  SELECT (
    SELECT json_array(p.time,${powerSql('p.data')}) FROM samples p INDEXED BY channel_history
    WHERE p.direction=?1 AND p.key=?2 AND p.time BETWEEN b.start AND min(b.start+?5-1,?4)
    ORDER BY p.time DESC LIMIT 1
  ) AS point FROM buckets b ORDER BY b.start
`);
const sampleExport = db.prepare(`SELECT time,key,data FROM samples
  WHERE direction=? AND time BETWEEN ? AND ? AND (time,key)>(?,?) ORDER BY time,key LIMIT 2048`);
const eventQuery = db.prepare('SELECT id,time,priority,message FROM events WHERE time BETWEEN ? AND ? ORDER BY time DESC,id');
const publicEvent = row => ({...row,message:redact(row.message),reference:eventReference(row.message)});
const eventById=db.prepare('SELECT id,time,priority,message FROM events WHERE id=?');
const beforeRF=db.prepare('SELECT time FROM samples WHERE direction=? AND time>=? AND time<? ORDER BY time DESC LIMIT 1');
const afterRF=db.prepare('SELECT time FROM samples WHERE direction=? AND time>=? AND time<=? ORDER BY time LIMIT 1');
const nearbyRanging=db.prepare('SELECT time,counts FROM ranging WHERE time BETWEEN ? AND ? ORDER BY time');
function eventReference(message) {
  const match=message.match(/\b(upstream|downstream|us|ds)\s+chan(?:nel)?(?:\s*(id|#))?\s*[:#=]?\s*(\d{1,5})\b/i);
  const frequency=message.match(/\b(?:frequency|freq)\s*[:=]?\s*(\d+(?:\.\d+)?\s*(?:MHz|kHz|Hz))\b/i);
  return {direction:match ? (/^(us|upstream)$/i.test(match[1])?'upstream':'downstream') :
    /\bdownstream\b/i.test(message)?'downstream':/\bupstream\b|\branging\b|\bT[1-4]\b/i.test(message)?'upstream':null,
    channel:match?Number(match[3]):null,explicitId:Boolean(match?.[2]),frequencyHz:frequencyHz(frequency?.[1])};
}
function correlation(event) {
  const at=event.time, span=120000, counterSpan=30000;
  const ref=eventReference(event.message);
  const ranging=nearbyRanging.all(at-counterSpan,at+counterSpan);
  const directions=Object.fromEntries(rfDirections.map(direction=>{
    const t0=beforeRF.get(direction,at-span,at)?.time;
    const t1=afterRF.get(direction,at,at+span)?.time;
    const before=t0==null?[]:publicRows(readAt(direction,t0));
    const after=t1==null?[]:publicRows(readAt(direction,t1));
    const pre=new Map(before.map(row=>[row.key,row])), post=new Map(after.map(row=>[row.key,row]));
    const keys=new Map([...pre,...post]);
    const counts=new Map();
    if (direction==='upstream') for (const record of ranging) for (const item of JSON.parse(record.counts)) {
      const candidates=[...keys.values()].filter(row=>item.key ? item.key===row.key :
        String(item.id)===String(row.id ?? row.frequency) && (!item.type || item.type===row.type));
      if(candidates.length!==1) continue;
      const key=candidates[0].key;
      const sum=counts.get(key) ?? {t3:0,t4:0};
      sum.t3+=item.t3 ?? 0;
      sum.t4+=item.t4 ?? 0;
      counts.set(key,sum);
    }
    const direct = ref.direction==null || direction===ref.direction ?
      [...keys.values()].filter(row=>(ref.explicitId || ref.frequencyHz!=null) &&
        (!ref.explicitId || String(row.id)===String(ref.channel)) &&
        (ref.frequencyHz==null || row.frequencyHz===ref.frequencyHz)) : [];
    const delta=(a,b,name)=>Number.isFinite(a?.[name]) && Number.isFinite(b?.[name]) ?
      +(b[name]-a[name]).toFixed(2):null;
    const rows=[...keys].map(([key,row])=>{
      const old=pre.get(key), next=post.get(key);
      const power=delta(old,next,'power'), mer=delta(old,next,'mer');
      const lockChanged=old?.lock!=null && next?.lock!=null && old.lock!==next.lock;
      const reported=direct.length===1 && direct[0].key===key;
      const c=counts.get(key);
      const reason=[...(reported?['Log identifies channel']:[]),...(c?['Nearby ranging counter increase']:[]),
        ...(power || mer || lockChanged?['RF change near event']:[])];
      return {key,id:row.id,type:row.type,frequencyHz:row.frequencyHz,before:old?.power ?? null,after:next?.power ?? null,
        power,mer,lockChanged,reported,t3:c?.t3 ?? 0,t4:c?.t4 ?? 0,reason};
    }).sort((a,b)=>Number(b.reported)-Number(a.reported)||(b.t3+b.t4-a.t3-a.t4)||
      Number(b.lockChanged)-Number(a.lockChanged)||Math.abs(b.power ?? 0)-Math.abs(a.power ?? 0));
    return [direction,{before:t0 ?? null,after:t1 ?? null,rows}];
  }));
  return {event:publicEvent(event),reference:ref,from:Math.max(0,at-span),to:at+span,directions};
}
function bounds(url) {
  const from = Number(url.searchParams.get('from') ?? Date.now()-day);
  const to = Number(url.searchParams.get('to') ?? Date.now());
  if (!Number.isSafeInteger(from) || !Number.isSafeInteger(to) || from < 0 || to <= from || to > 8640000000000000 || to-from > 366*day) {
    throw Object.assign(Error('Choose a valid range up to 366 days'),{status:400});
  }
  return [from,to];
}
const timeout = message => message.match(/\bT[1-4]\b/i)?.[0].toUpperCase();
function incidents(events, ranging) {
  const groups = [];
  for (const row of [...events,...ranging].sort((a,b) => b.time-a.time)) {
    const tag = row.counts ? 'Counter increase' : timeout(row.message) || (/dynamic range window|\bDRW\b/i.test(row.message) ? 'DRW' :
      /ranging.*retries exhausted/i.test(row.message) ? 'Retries exhausted' : null);
    if (!tag) continue;
    let group = groups.at(-1);
    if (!group || group.first-row.time > 300000) {
      group = {first:row.time,last:row.time, tags:{}, count:0, ranging:[]};
      groups.push(group);
    }
    group.first = row.time;
    group.tags[tag] = (group.tags[tag] ?? 0)+1;
    group.count++;
    if (row.counts) group.ranging.push({time:row.time, channels:JSON.parse(row.counts)});
  }
  return groups;
}
function evidence(group) {
  const margin = settings().interval*2000;
  return Object.fromEntries(['downstream','upstream'].map(direction => {
    const nearest = db.prepare('SELECT min(time) AS time FROM samples WHERE direction=? AND time BETWEEN ? AND ?').get(direction,group.first-margin,group.first+margin).time;
    const end = db.prepare('SELECT max(time) AS time FROM samples WHERE direction=? AND time BETWEEN ? AND ?').get(direction,group.last-margin,group.last+margin).time;
    if (nearest == null || end == null) return [direction,null];
    const startRows = readAt(direction,nearest);
    const endRows = readAt(direction,end);
    const before = new Map(startRows.map(row => [row.key,row]));
    const differences = endRows.filter(row => before.has(row.key)).map(row => {
      const prev = before.get(row.key);
      const diff = name => displayMetric(row,name) == null || displayMetric(prev,name) == null ? null :
        +(displayMetric(row,name)-displayMetric(prev,name)).toFixed(2);
      return {id:row.id ?? row.frequency, type:row.type,power:diff('power'),mer:diff('mer'),lock: row.lock !== prev.lock && row.lock != null && prev.lock != null ? row.lock : null};
    });
    const changes = differences.filter(row => row.power || row.mer || row.lock != null);
    const totals = Object.create(null);
    const resets = new Set();
    for (const sample of db.prepare('SELECT data FROM samples WHERE direction=? AND time BETWEEN ? AND ?').iterate(direction,nearest+1,end)) {
      const row = JSON.parse(sample.data);
      // The first sample's deltas start before this evidence window.
      for (const [key,value] of Object.entries(row.delta)) {
        if (value != null) totals[key] = (totals[key] ?? 0)+value;
      }
      for (const key of row.reset) resets.add(key);
    }
    return [direction,{from:nearest,to:end,changes,totals,resets:[...resets],
      added:endRows.filter(row => !before.has(row.key)).length,
      removed:startRows.filter(row => !endRows.some(endRow => endRow.key === row.key)).length}];
  }));
}
function csvCell(value) {
  if (value == null) return '';
  let s = String(value);
  if (typeof value === 'string' && /^[\s]*[=+\-@]|^[\t\r\n]/.test(s)) s = "'"+s;
  return '"'+s.replaceAll('"','""')+'"';
}
async function csv(res, name, headers, rows) {
  res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="'+name+'.csv"'});
  res.write(headers.join(',')+'\r\n');
  for (const row of rows) {
    if (res.destroyed) return;
    if (!res.write(row.map(csvCell).join(',')+'\r\n')) {
      const signal = AbortSignal.timeout(30000);
      await once(res,'drain',{signal});
    }
  }
  res.end();
}
function* rfCsv(range) {
  for (const direction of ['downstream','upstream']) {
    // Materialize only a bounded page, even at 500 ms and many channels.
    let time=range[0]-1,key='';
    while (true) {
      const page=sampleExport.all(direction,...range,time,key);
      for (const sample of page) {
        const r = JSON.parse(sample.data);
        yield [new Date(sample.time).toISOString(),direction,r.id,r.type,r.frequency,r.modulation,r.status,
          ...Object.keys(metrics).map(k => displayMetric(r,k)),...counters.map(k => r.delta[k]),r.reset.join(' '),Number(r.lockChanged)];
      }
      if (page.length<2048) break;
      ({time,key}=page.at(-1));
    }
  }
}
const json = (res,data,status=200) => {
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify(data));
};
const files = Object.fromEntries([['/','index.html','text/html'],['/app.js','app.js','text/javascript'],['/theme.js','theme.js','text/javascript'],
  ['/timeline.js','timeline.js','text/javascript'],['/power.js','power.js','text/javascript'],['/style.css','style.css','text/css']]
  .map(([path,name,mime]) => [path,{mime,body:readFileSync(new URL('public/'+name,import.meta.url))}]));
const port=Number(process.env.PORT ?? 3000);
const webPort=Number(process.env.DASHBOARD_WEB_PORT ?? port);
function parseOrigin(value) {
  if (typeof value!=='string' || !/^https?:\/\/[^\s/\\?#@,%]+\/?$/i.test(value)) return null;
  try {return new URL(value);} catch {return null;}
}
const authority=value=>parseOrigin('http://'+(value ?? ''))?.host;
const origins=new Set(), allowedHosts=new Set();
for (const value of ['http://localhost:'+port,'http://127.0.0.1:'+port,'http://[::1]:'+port,
  'http://localhost:'+webPort,'http://127.0.0.1:'+webPort,'http://[::1]:'+webPort,
  ...(process.env.DASHBOARD_BIND_IP ? ['http://'+process.env.DASHBOARD_BIND_IP+':'+webPort] : []),
  ...(process.env.DASHBOARD_ORIGINS ?? '').split(',').map(v=>v.trim()).filter(Boolean)]) {
  const parsed=parseOrigin(value);
  if (!parsed) throw Error('Invalid dashboard origin configuration');
  origins.add(parsed.origin);
  allowedHosts.add(authority(parsed.host));
}
const heavy=new Set(['/api/power','/api/history','/api/rf.csv','/api/events','/api/events.csv']);
let heavyRequests=0;
const server = http.createServer({headersTimeout:10000,requestTimeout:10000},async (req,res) => {
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Content-Security-Policy',"default-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Cross-Origin-Resource-Policy','same-origin');
  let acquired=false;
  try {
    const host=authority(req.headers.host);
    if (!host || !allowedHosts.has(host)) return json(res,{error:'Unrecognised dashboard host'},421);
    if (!req.url.startsWith('/') || req.url.startsWith('//')) return json(res,{error:'Invalid request target'},400);
    const url = new URL(req.url,'http://localhost');
    const path = url.pathname;
    if (req.method === 'POST' && ['/api/settings','/api/capture'].includes(path)) {
      const origin=parseOrigin(req.headers.origin);
      if (!origin || !origins.has(origin.origin) || authority(origin.host)!==host ||
          !/^application\/json(?:;|$)/i.test(req.headers['content-type'] ?? '')) return json(res,{error:'Settings require a same-origin JSON request'},403);
      let body = '';
      for await (const part of req) {
        body += part;
        if (body.length > 4096) return json(res,{error:'Settings request too large'},413);
      }
      let values;
      try { values = JSON.parse(body); } catch { return json(res,{error:'Invalid JSON'},400); }
      if (path==='/api/capture') {
        if (typeof values?.paused!=='boolean') return json(res,{error:'Set paused to true or false'},400);
        changePause(values.paused);
        return json(res,{paused});
      }
      const {interval,retention} = values ?? {};
      if (typeof interval!=='number' || interval<0.5 || interval>900 || !Number.isInteger(interval*2) ||
          !Number.isInteger(retention) || retention < 1 || retention > 365) return json(res,{error:'Use 0.5–900 seconds in half-second steps and 1–365 retention days'},400);
      const previous = settings();
      db.prepare('UPDATE settings SET interval=?, retention=? WHERE id=1').run(interval,retention);
      if (retention < previous.retention) prune(Date.now());
      if (interval !== previous.interval) for (const source of captureSources) schedule(source);
      return json(res,settings());
    }
    if (req.method !== 'GET') return json(res,{error:'Method not allowed'},405);
    if (heavy.has(path)) {
      if (heavyRequests>=4) return json(res,{error:'The monitor is busy. Retry the history query shortly.'},503);
      heavyRequests++;
      acquired=true;
    }
    if (Object.hasOwn(files,path)) {
      res.writeHead(200,{'Content-Type':files[path].mime+'; charset=utf-8','Cache-Control':'no-cache'});
      return res.end(files[path].body);
    }
    if (path === '/healthz') return json(res,{ok:db.prepare('SELECT 1 AS ok').get().ok===1});
    if (path === '/api/live') {
      const direction=url.searchParams.get('direction');
      const clients=liveClients.get(direction);
      if (!clients) return json(res,{error:'Supply a valid direction'},400);
      if ([...liveClients.values()].reduce((count,set)=>count+set.size,0)>=48) return json(res,{error:'Live viewer limit reached'},503);
      res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','X-Accel-Buffering':'no'});
      clients.add(res);
      res.once('close',()=>clients.delete(res));
      sendLive(res,'retry: 1500\nevent: ready\ndata: '+JSON.stringify({serverTime:Date.now(),paused})+'\n\n'+(latestFrames.get(direction) ?? ''));
      return;
    }
    if (path === '/api/status') {
      const status = db.prepare('SELECT * FROM source_status').all();
      const current = Object.fromEntries(['downstream','upstream'].map(d => {
        const rows = readAt(d,status.find(s => s.source === d)?.good ?? 0);
        return [d,publicRows(rows)];
      }));
      const config = settings();
      return json(res,{settings:config,status,current,hub:hub.origin,paused,
        cadenceMs:Object.fromEntries(sources.map(source=>[source,cadence(source,config.interval)]))});
    }
    if (path==='/api/modem') return json(res,{...inventory,paused});
    if (path==='/api/correlation') {
      const id=url.searchParams.get('event');
      let event;
      if(id) {
        event=eventById.get(id);
        if (!event) return json(res,{error:'Event is no longer in history'},404);
      } else {
        const at=Number(url.searchParams.get('at'));
        if (!Number.isSafeInteger(at) || at<=0 || at>8640000000000000-120000) return json(res,{error:'Choose a valid event time'},400);
        event={time:at,message:'Ranging incident',priority:'incident'};
      }
      return json(res,correlation(event));
    }
    if (path === '/api/channels') {
      const range = bounds(url);
      return json(res,Object.fromEntries(['downstream','upstream'].map(d => [d,availableKeys(d,range)])));
    }
    if (path === '/api/power') {
      const direction = url.searchParams.get('direction');
      if (!['downstream','upstream'].includes(direction)) return json(res,{error:'Supply a valid direction'},400);
      const [from,to] = bounds(url);
      const bucketMs = to-from<=rawSpan ? 1 : Math.max(1,Math.ceil((to-from+1)/600));
      const series = [];
      for (const key of availableKeys(direction,[from,to])) {
        const points = bucketMs===1 ? rawPowerSeries.all(direction,key,from,to) :
          powerSeries.all({'1':direction,'2':key,'3':from,'4':to,'5':bucketMs}).flatMap(({point})=>{
            if (point==null) return [];
            const [time,power]=JSON.parse(point);
            return [{time,power}];
          });
        if (points.some(p=>Number.isFinite(p.power))) series.push({key,points});
        await yieldToLoop();
        if (res.destroyed) return;
      }
      return json(res,{from,to,bucketMs,series});
    }
    if (path === '/api/history') {
      const direction = url.searchParams.get('direction');
      const key = url.searchParams.get('key');
      if (!['downstream','upstream'].includes(direction) || !key) return json(res,{error:'Supply direction and channel'},400);
      const range = bounds(url);
      const history = [];
      const metric = url.searchParams.get('metric');
      if (![...Object.keys(metrics),'lock'].includes(metric)) return json(res,{error:'Unknown metric'},400);
      const bucketSize = range[1]-range[0]<=rawSpan ? 1 : Math.max(1,Math.ceil((range[1]-range[0]+1)/450));
      let bucket;
      const isCounter = counters.includes(metric);
      let next = range[0];
      while (next <= range[1]) {
        const page = samplesQuery.all(direction,key,next,range[1]);
        for (const sample of page) {
          const r = JSON.parse(sample.data);
          const value = isCounter ? r.delta?.[metric] : displayMetric(r,metric);
          const index = Math.floor((sample.time-range[0])/bucketSize);
          if (!bucket || index !== bucket.index) {
            bucket = {index,time:sample.time,last:sample.time,min:null,max:null,sum:null,count:0,resets:0};
            history.push(bucket);
          }
          bucket.last = sample.time;
          if (r.reset?.includes(metric)) bucket.resets++;
          if (!Number.isFinite(value)) continue;
          bucket.min = bucket.min == null ? value : Math.min(bucket.min,value);
          bucket.max = bucket.max == null ? value : Math.max(bucket.max,value);
          bucket.sum += value;
          bucket.count++;
        }
        if (page.length < 2048) break;
        next = page.at(-1).time+1;
        await yieldToLoop();
        if (res.destroyed) return;
      }
      return json(res,{history,bucketMs:bucketSize,
        ...(url.searchParams.get('seriesOnly') === '1' ? {} : {available:availableKeys(direction,range)})});
    }
    if (path === '/api/events' || path === '/api/events.csv') {
      const range = bounds(url);
      const rows = eventQuery.all(...range).map(publicEvent);
      if (path.endsWith('.csv')) return await csv(res,'hub5-events',['time_utc','priority','message'],
        rows.map(r => [new Date(r.time).toISOString(),r.priority,r.message]));
      const summaries = Object.create(null);
      for (const row of rows) {
        const date = new Date(row.time).toISOString().slice(0,10);
        const counts = summaries[date] ??= {events:0,critical:0,T1:0,T2:0,T3:0,T4:0};
        counts.events++;
        if (row.priority === 'critical') counts.critical++;
        const tag = timeout(row.message);
        if (tag) counts[tag]++;
      }
      const ranging = db.prepare('SELECT time,counts FROM ranging WHERE time BETWEEN ? AND ? ORDER BY time DESC').all(...range);
      const groups = incidents(rows,ranging);
      return json(res,{total:rows.length,events:rows.slice(0,250),summaries,
        incidents:groups.slice(0,50).map(group => ({...group,rf:evidence(group)}))});
    }
    if (path === '/api/rf.csv') return await csv(res,'hub5-rf',
      ['time_utc','direction','channel_id','channel_type','frequency_as_reported','modulation','status',
        ...Object.keys(metrics),...counters.map(k => 'delta_'+k),'counter_decreases','lock_changed'],rfCsv(bounds(url)));
    return json(res,{error:'Not found'},404);
  } catch (error) {
    if (!error.status) console.error(error);
    if (res.headersSent) return res.destroy();
    json(res,{error:error.status ? error.message : 'Internal error'},error.status ?? 500);
  } finally {
    if (acquired) heavyRequests--;
  }
});
server.listen(port,process.env.LISTEN_HOST ?? '0.0.0.0',() => {
  console.log('Hub 5 DOCSIS Monitor listening on port '+server.address().port);
  for (const source of captureSources) {
    collectors[source].timestamp = lastAttempt.get(source)?.attempted ?? 0;
    poll(source);
  }
  const maintain = () => {
    try { prune(Date.now()); } catch (error) { console.error(error); }
  };
  setImmediate(maintain);
  setInterval(maintain,3600000).unref();
  setInterval(()=>{
    for (const clients of liveClients.values()) for (const res of clients) sendLive(res,': heartbeat\n\n');
  },15000).unref();
});
