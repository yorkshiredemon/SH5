import http from 'node:http';
import https from 'node:https';
import {isIP} from 'node:net';

export const sources = ['downstream', 'upstream', 'eventlog'];
export const metrics = {
  power: ['power', 'powerLevel', 'rxPower', 'txPower', 'receivePower', 'transmitPower', 'signalPower', 'powerDbmv', 'powerLevelDbmv', 'powerdBmV'],
  mer: ['mer', 'snr', 'rxMer', 'signalNoiseRatio', 'signalToNoiseRatio', 'merDb', 'snrDb', 'rxMerDb'],
  corrected: ['corrected', 'correctables', 'correctedErrors', 'correctedCodewords', 'correctableCodewords', 'correctableErrors', 'correcteds'],
  uncorrectable: ['uncorrectable', 'uncorrectables', 'uncorrected', 'uncorrectedErrors', 'uncorrectableErrors', 'uncorrectableCodewords', 'uncorrectedCodewords', 'uncorrecteds'],
  ...Object.fromEntries([1,2,3,4].map(n => ['t'+n, ['t'+n, 't'+n+'Timeout', 't'+n+'Timeouts', 't'+n+'TimeoutCount', 't'+n+'Count']]))
};
export const counters = Object.keys(metrics).filter(k => !['power','mer'].includes(k));
const canonical = key => key.toLowerCase().replace(/[^a-z0-9]/g, '');
const fields = row => Object.fromEntries(Object.entries(row ?? {}).map(([k,v]) => [canonical(k),v]));
const pick = (row, names) => names.map(k => row[canonical(k)]).find(v => v !== undefined && v !== null && v !== '');
function numeric(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  const match = typeof value === 'string' && value.trim().match(/^(-?\d+(?:\.\d+)?)\s*(?:dBmV|dB|Hz|MHz)?$/i);
  return match ? Number(match[1]) : null;
}
const rfToken=value=>typeof value==='string' && /^[\w -]{1,40}$/.test(value) ? value : null;
const channelId=value=>typeof value==='number' && Number.isSafeInteger(value) && value>=0 && value<=65535 ||
  typeof value==='string' && /^\d{1,5}$/.test(value) && Number(value)<=65535 ? value : null;
function rawRF(row, originalType) {
  // Retain only the extra RF metadata used by the monitor. Do not save the
  // arbitrary upstream payload (which may have new fields in future firmware).
  const result={};
  const typed=[
    ['channelType',rfToken(originalType)],
    ['fftType',rfToken(row.ffttype)],
    ['numberOfActiveSubCarriers',numeric(row.numberofactivesubcarriers)],
    ['firstActiveSubcarrier',numeric(row.firstactivesubcarrier)],
    ['channelWidth',frequencyHz(pick(row,['channelWidth','channelWidthHz','bandwidth','bandwidthHz']))],
    ['symbolRate',numeric(row.symbolrate)]
  ];
  for (const [key,value] of typed) if (value!=null) result[key]=value;
  return result;
}
export function channels(payload, direction) {
  const rows = payload?.[direction]?.channels;
  if (!Array.isArray(rows)) throw Error('Missing '+direction+'.channels array');
  const keys = new Set();
  return rows.map(channel => {
    if (!channel || typeof channel !== 'object' || Array.isArray(channel)) throw Error('Invalid channel object');
    const row = fields(channel);
    const id = channelId(pick(row, ['channelId','id','channelNumber','channelIndex','index']));
    const originalType=rfToken(pick(row, ['channelType','type']));
    const type = (originalType ?? 'unknown').toUpperCase();
    const reportedFrequency=pick(row,['frequency','frequencyHz','centerFrequency','centralFrequency','channelFrequency','plcFrequency']);
    const frequency=frequencyHz(reportedFrequency)==null ? null : reportedFrequency;
    const key = JSON.stringify([type, id ?? frequency ?? null, frequency ?? null]);
    if ((id == null && frequency == null) || keys.has(key)) throw Error('Missing or duplicate channel identity');
    keys.add(key);
    const rawStatus=pick(row,['locked','lockStatus','channelLock','channelStatus','status','lock','isLocked']);
    const status=typeof rawStatus==='boolean' || rawStatus===0 || rawStatus===1 ? rawStatus : rfToken(rawStatus);
    const lock = /^(true|1|locked|acquired)$/i.test(String(status)) ? 1 :
      /^(false|0|unlocked|not locked|notlocked|lost)$/i.test(String(status)) ? 0 : null;
    const lookup = {...fields(row.fec), ...fields(row.timeouts), ...fields(row.statistics), ...row};
    return {key, id, type, frequency, lock, status, modulation:rfToken(row.modulation), raw:rawRF(row,originalType),
      ...Object.fromEntries(Object.entries(metrics).map(([name, aliases]) => {
        const value = numeric(pick(lookup, aliases));
        return [name, counters.includes(name) && (!Number.isSafeInteger(value) || value < 0) ? null : value];
      }))};
  });
}
export function redact(message) {
  return String(message ?? '')
    // Explicitly tagged values can have formats other than MACs or IPs.
    .replace(/\b((?:(?:cmts?|cpe|client|device|src|dst)[ _-]?)?(?:mac(?:[ _-]?address)?|ip(?:v[46])?(?:[ _-]?address)?)|serial(?:[ _-]?number)?|username|user[ _-]?(?:name|id)|host[ _-]?name|client[ _-]?(?:id|name)|ssid|password|passphrase|(?:access[ _-]?)?token|authorization|email)\s*[:=]\s*(?:"[^"]*"|'[^']*'|[^;\r\n,]+)/gi,'$1=[redacted]')
    .replace(/\b(?:[a-f\d]{2}[:-]){5}[a-f\d]{2}\b|\b[a-f\d]{4}(?:\.[a-f\d]{4}){2}\b/gi,'[redacted]')
    .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,'[redacted]')
    .replace(/[a-f\d:.]+(?:%[a-z\d_.~-]+)?/gi,word=>{
      const value=word.replace(/\.+$/,'');
      return isIP(value)===6 ? '[redacted]'+word.slice(value.length) : word;
    })
    .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g,word=>isIP(word)===4?'[redacted]':word)
    .slice(0,4096);
}
export function events(payload) {
  if (!Array.isArray(payload?.eventlog)) throw Error('Missing eventlog array');
  return payload.eventlog.map(row => {
    const time = Date.parse(row?.time);
    if (!Number.isFinite(time) || typeof row.message !== 'string' || typeof row.priority !== 'string') throw Error('Invalid event log row');
    return {time, priority: row.priority.toLowerCase(), message: row.message};
  });
}
export function frequencyHz(value) {
  const match=String(value ?? '').trim().match(/^(\d+(?:\.\d+)?)\s*(hz|khz|mhz)?$/i);
  if (!match) return null;
  const hz=Number(match[1])*({hz:1,khz:1000,mhz:1000000}[match[2]?.toLowerCase() ?? 'hz']);
  return Number.isFinite(hz) && hz>=1000000 ? hz : null;
}
// The VM Hub 5's own UI renders OFDM rxMer and power in tenths.
// Recognise that payload shape on read, including existing JSON in SQLite.
export function hub5Ofdm(row) {
  return row?.raw?.channelType==='ofdm' && typeof row.raw.fftType==='string' &&
    Number.isFinite(row.raw.numberOfActiveSubCarriers);
}
export function displayMetric(row,name) {
  const value=row[name];
  return Number.isFinite(value) && (name==='power' || name==='mer') && hub5Ofdm(row) ? value/10 : value;
}
export function rfMetadata(row) {
  const raw=fields(row.raw);
  return {frequencyHz:frequencyHz(row.frequency),
    widthHz:frequencyHz(pick(raw,['channelWidth','channelWidthHz','bandwidth','bandwidthHz'])),
    symbolRateKsps:numeric(raw.symbolrate),
    fftType:typeof raw.ffttype==='string' ? raw.ffttype : null,
    activeSubcarriers:numeric(raw.numberofactivesubcarriers),
    firstActiveRaw:numeric(raw.firstactivesubcarrier)};
}
export function getHub(base, source, rejectUnauthorized, cancel) {
  const url = new URL('/rest/v1/cablemodem/'+source, base);
  const client = url.protocol === 'https:' ? https : http;
  return new Promise((resolve, reject) => {
    const req = client.get(url, {
      rejectUnauthorized, signal: cancel ? AbortSignal.any([cancel,AbortSignal.timeout(10000)]) : AbortSignal.timeout(10000), headers: {Accept:'application/json'}
    }, res => {
      if (res.statusCode !== 200) {
        res.resume();
        reject(Error('Hub returned HTTP '+res.statusCode));
        return;
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('error', reject);
      res.on('data', chunk => {
        body += chunk;
        if (body.length > 2_000_000) req.destroy(Error('Hub response exceeded size limit'));
      });
      res.on('end', () => {
        try { resolve(JSON.parse(body)); }
        catch { reject(Error('Hub response was not JSON')); }
      });
    });
    req.on('error', reject);
  });
}
